<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NMI - National Mathematics Initiative</title>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
<link href="scripts/imi.css" rel="stylesheet" type="text/css" />
<!-- Form Validation Assets Begin -->
<link rel="stylesheet" type="text/css" media="screen" href="scripts/screen.css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="lib/jquery.metadata.js" type="text/javascript"></script>
<script src="scripts/jquery.validate.js" type="text/javascript"></script>
<script src="lib/cmxforms.js" type="text/javascript"></script>
<style type="text/css">
.cmxform fieldset p.error label {
	color: red;
}
div.container {
	background-color: #eee;
	border: 1px solid red;
	margin: 5px;
	padding: 5px;
}
div.container ol li {
	list-style-type: disc;
	margin-left: 20px;
}
div.container {
	display: none
}
.container label.error {
	display: inline;
}
form.cmxform {
}
form.cmxform label.error {
	display: block;
	margin-left: 1em;
	width: auto;
}
</style>
<script type="text/javascript">
// only for demo purposes
//$.validator.setDefaults({
//	submitHandler: function() {
//		alert("submitted! (skipping validation for cancel button)");
//	}
//});

$().ready(function() {
	$("#RFP").validate({
		errorLabelContainer: $("#RFP div.error")
	});
	
	var container = $('div.container');
	// validate the form when it is submitted	
	$(".cancel").click(function() {
		validator.resetForm();
	});
	

});
</script>
<!-- Form Valiation Assets End -->
</head>
<body onload="MM_preloadImages('images/lnk-aboutimi1.jpg','images/lnk-seminars1.jpg','images/lnk-thematicprog2.jpg','images/lnk-thematicprog1.jpg','images/lnk-phdprog1.jpg','images/lnk-requestforpart1.jpg','images/lnk-visitorinfo1.jpg','images/lnk-fundingagencies1.jpg','images/lnk-contact1.jpg')">
<a name="top" id="top"></a>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;&nbsp;
      <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = '<? print date("F d, Y H:i:s", time())?>' //PHP method of getting server date
var currenttime = '<? print date("F d, Y H:i:s")?>' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime"></span>&nbsp;</td>
    <td align="right"><a href="index.php"><img src="images/icon-home.jpg" width="27" height="25" border="0" align="absmiddle" /></a>&nbsp;<a href="index.php">Home</a>&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><img src="images/spacer.gif" width="50" height="10" /></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="aboutimi-overview.php" target="_top" onclick="MM_nbGroup('down','group1','aboutimi','images/lnk-aboutimi1.jpg',1)" onmouseover="MM_nbGroup('over','aboutimi','images/lnk-aboutimi1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-aboutimi.jpg" alt="About NMI" name="aboutimi" width="108" height="31" border="0" id="aboutimi" onload="" /></a></td>
    <td><a href="atp.php" target="_top" onclick="MM_nbGroup('down','group1','thematicprogrammes','images/lnk-thematicprog1.jpg',1)" onmouseover="MM_nbGroup('over','thematicprogrammes','images/lnk-thematicprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-thematicprog.jpg" alt="Thematic Programmes" name="thematicprogrammes" width="120" height="31" border="0" id="thematicprogrammes" onload="" /></a></td>
    <td><a href="otherevents.php" target="_top" onclick="MM_nbGroup('down','group1','otherevents','images/lnk-otherevents1.jpg',1)" onmouseover="MM_nbGroup('over','otherevents','images/lnk-otherevents1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-otherevents.jpg" alt="Other Events" name="otherevents" width="107" height="31" border="0" id="otherevents" onload="" /></a></td>
    <td><a href="PhD Home.php" target="_top" onclick="MM_nbGroup('down','group1','phdprogrammes','images/lnk-phdprog1.jpg',1)" onmouseover="MM_nbGroup('over','phdprogrammes','images/lnk-phdprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-phdprog.jpg" alt="Ph.d Programmes" name="phdprogrammes" width="133" height="31" border="0" id="phdprogrammes" onload="" /></a></td>
    <td><a href="atp-requestforparticipation.php" target="_top" onclick="MM_nbGroup('down','group1','requestforpart','images/lnk-requestforpart1.jpg',1)" onmouseover="MM_nbGroup('over','requestforpart','images/lnk-requestforpart1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-requestforpart.jpg" alt="Request for Participation" name="requestforpart" width="110" height="31" border="0" id="requestforpart" onload="" /></a></td>
    <td><a href="visitorinfo.php" target="_top" onclick="MM_nbGroup('down','group1','visitorinfo','images/lnk-visitorinfo1.jpg',1)" onmouseover="MM_nbGroup('over','visitorinfo','images/lnk-visitorinfo1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-visitorinfo.jpg" alt="Visitor and Local Information" name="visitorinfo" width="112" height="31" border="0" id="visitorinfo" onload="" /></a></td>
    <td><a href="fundingagencies.php" target="_top" onclick="MM_nbGroup('down','group1','fundingagencies','images/lnk-fundingagencies1.jpg',1)" onmouseover="MM_nbGroup('over','fundingagencies','images/lnk-fundingagencies1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-fundingagencies.jpg" alt="Funding Agencies" name="fundingagencies" width="81" height="31" border="0" id="fundingagencies" onload="" /></a></td>
    <td><a href="contact.php" target="_top" onclick="MM_nbGroup('down','group1','contact','images/lnk-contact1.jpg',1)" onmouseover="MM_nbGroup('over','contact','images/lnk-contact1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-contact.jpg" alt="Contact" name="contact" width="82" height="31" border="0" id="contact" onload="" /></a></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
  <tr>
    <td><img src="images/bannerimg-main.jpg" alt="National Mathematics Initiative (NMI)" width="880" height="190" /></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
</table>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3" background="../images/div-horz-header.jpg"><img src="images/spacer.gif" width="10" height="35" align="absmiddle" /><span class="headmain">OTHER EVENTS</span><span class="head1"><span class="headmain"> </span><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /></span></td>
  </tr>
  <tr>
    <td align="left" valign="top" background="../images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td align="left" valign="top" background="../images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td width="650" align="left" valign="top" background="../images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
  </tr>
  <tr>
    <td width="220" align="left" valign="top"><table width="220" border="0" cellspacing="0" cellpadding="5">
      <tr>
        <td><p>&raquo; Seminars/Colloquia</p>
          <ul class="format">
            <li><a href="otherevents-seminars.php">Latest</a></li>
            <li><a href="otherevents-seminars-past.php">Past</a></li>
          </ul>
          <hr class="blue" />
          <p> &raquo; Other Workshops/Conferences</p>
          <ul class="format">
            <li><a href="otherevents-workshops.php">Latest</a></li>
            <li><a href="otherevents-workshops-past.php">Past</a></li>
          </ul>
          <hr class="blue" />
          <p> &raquo; Compact Courses</p>
          <ul class="format">
            <li><a href="otherevents-compact.php">Latest</a></li>
            <li><a href="otherevents-compact-past.php">Past</a></li>
          </ul></td>
      </tr>
    </table></td>
    <td width="10" align="left" valign="top" background="../images/div-vert-links.jpg"><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /></td>
    <td align="left" valign="top"><p><strong>PAST SEMINARS/COLLOQUIA</strong>
     <p align="justify">&nbsp;</p>
      <p align="justify">&nbsp;</p>
      <ul>
        <li><a href="#2013">2013</a></li>
        <li><a href="#2012">2012</a></li>
        <li><a href="#2010">2010</a></li>
        <li><a href="#2009">2009</a></li>
        <li><a href="#2008">2008</a></li>
        <li><a href="#2007">2007</a></li>
        <li><a href="#2006">2006</a></li>
        <li><a href="#2005">2005</a></li>
        <li><a href="#2004">2004</a></li>
        <li><a href="#2003">2003</a></li>
      </ul>
      <hr align="center" width="600" />
      <table width="500" border="0" cellspacing="0" cellpadding="5">
        <tr>
          <td><span class="headsub1"><a name="2013" id="20094"></a>2013</span></td>
          <td align="right"></td>
        </tr>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr bgcolor="#e1e1e1" valign="top">
            <td width="70"><strong>Date</strong></td>
            <td width="70"><strong>Time</strong></td>
            <td width="160"><strong>Speaker</strong></td>
            <td width="200"><strong>Topic</strong></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">28 Jan 2013</td>
            <td width="70">3.30 pm</td>
            <td width="160"><p>Mr. Samar Bahadur Singh</p></td>
            <td width="200">Study of higher order split-step methods for  stiff Stochastic differential equations</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="colloq/samarbahadur.htm" target="_blank">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table width="500" border="0" cellspacing="0" cellpadding="5">
        <tr>
          <td><span class="headsub1"><a name="2012" id="20093"></a>2012</span></td>
          <td align="right"></td>
        </tr>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">28 Dec 2012</td>
            <td width="70">4.00 pm</td>
            <td width="160">Ravi Prasad K. J.</td>
            <td width="200">Development of Efficient Computational Methods  for Better Estimation of Optical Properties in Diffuse Optical Tomography</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="colloq/ravi-prasad.htm" target="_blank">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">01 July 2012</td>
            <td width="70">3.00 pm</td>
            <td width="160">Ms. Saswati Dana</td>
            <td width="200">Computational Studies of Uncertainty in  Intra-Cellular Biochemical</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="colloq/ravi-prasad.htm" target="_blank">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table width="500" border="0" cellspacing="0" cellpadding="5">
        <tr>
          <td><span class="headsub1"><a name="2010" id="20092"></a>2010</span></td>
          <td align="right"></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
            <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
            <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
            <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">18.11.2010</td>
            <td width="70">11:00 am</td>
            <td width="160">Prof. Wolf Singer
              Director, Max Planck Institute for Brain Research
              Frankfurt/Main Frankfurt Institute for Advanced Studies</td>
            <td width="200">Distributed Processing and Temporal Codes in Neuronal Networks</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-11- Wolf Singer.php" target="_blank">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td width="70">24.12.2010 </td>
            <td width="70">04:00 pm</td>
            <td width="160">Prof. Uriel Frisch, Observatoire de la Cote d'Azur
              Nice, France
              
              &nbsp;</td>
            <td width="200">The tyger phenomenon for the Galerkin-truncated Burgers and
              Euler equations</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-10- Uriel.php ">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p align="justify"><span class="headsub1"><a name="2009" id="2009"></a>2009</span> </p>
      </p>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr bgcolor="#e1e1e1" valign="top">
            <td width="70"><strong>Date</strong></td>
            <td width="70"><strong>Time</strong></td>
            <td width="160"><strong>Speaker</strong></td>
            <td width="200"><strong>Topic</strong></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">05.01.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">Hans D. Mittelmann, Department of Math &amp; Stats, Arizona State University</td>
            <td width="200">Optimization Software for Financial Mathematics</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-HDM5.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">06.01.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">Hans D. Mittelmann, Department of Math &amp; Stats, Arizona State University</td>
            <td width="200">Support Vector Machines in Machine Learning</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-HDM6.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">16.01.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">D. W. Stroock, M.I.T, USA</td>
            <td width="200">Analysis of the Wright Fisher Equation</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-DWS.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">19.01.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">Hans G. Feichtinger , University of Vienna, Austria</td>
            <td width="200">Modulation Spaces and Banach Gelfand Triples</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-Hans.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">27.01.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">Francesco Mainardi, University of Bologna, Italy</td>
            <td width="200">Anomalous Diffusion via a Fractional Calculus Approach</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-Mainardi.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">10.02.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">Roger Howe, Mathematics Department, Yale University</td>
            <td width="200">Recent Trends in Invariant Theory</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-Roger.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" width="500">
        <tbody>
          <tr valign="top">
            <td width="70">16.03.2009<br />
              17.03.2009</td>
            <td width="70">&nbsp;</td>
            <td width="160">Ron Kerman, Brock University, St. Catharines, Canada</td>
            <td width="200">&quot;Sobolev in equalities on irregular domains&quot; and &quot;The rearrangement-invariant hull of a Sobolev Space&quot;.</td>
          </tr>
          <tr valign="top">
            <td width="70">&nbsp;</td>
            <td width="70">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td align="right" width="200"><a href="seminars-09-Roger.php">More Info.</a></td>
          </tr>
          <tr valign="top">
            <td colspan="4"><hr /></td>
          </tr>
        </tbody>
        <tr>
          <td width="70">30.03.2009<br />
            01.04.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">Victor Vinnikov,
            Department of  Mathematics,Ben Gurion University, Israel </td>
          <td width="200">&quot;Overdetermined multidimensional systems and dilation theory for
            pairs of commuting contractions&quot;.</td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-Roger.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">09.04.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">Michael Dritschel,
            Newcastle University, UK </td>
          <td width="200">&quot;Completely bounded kernels&quot;.</td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-RonKerman.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">20.04.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">M. K. Vemuri,
            Chennai Mathematical Institute,Chennai </td>
          <td width="200">&quot;The homogeneous shifts via inductive algebras&quot;.</td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-RonKerman.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">05.06.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">R. G. Douglas,
            Texas A&amp;M University </td>
          <td width="200">&quot;Operator Theory and Algebraic Topology&quot;.</td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-Roger.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">21.07.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">Manuel de Leon,
            Instituto de Ciencias Matematicas, Consejo Superior de Investigaciones Cientificas</td>
          <td width="200">&quot;The ubiquity of the symplectic Hamiltonian equations in mechanics&quot;.</td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-RonKerman.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">24.07.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">E. Zuazua,
            Scientific Director
            BCAM - Basque Center for Applied Mathematics, Spain </td>
          <td width="200">&quot;Wave Propagation on Networks&quot;.</td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-RonKerman.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">27.11.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">Rolf Jeltsch,
            Department of Mathematics ETH Zurich, Switzerland </td>
          <td width="200">&quot;High-order Semi-Lagrangian Numerical Method for the
            Large-Eddy and Simulation of Reactive Flows&quot; </td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-RonKerman.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
          <td colspan="4"><hr /></td>
        </tr>
        <tr>
          <td width="70">11.12.2009</td>
          <td width="70">&nbsp;</td>
          <td width="160">Arnaldo Garcia,
            IMPA, Brazil</td>
          <td width="200">&quot;On Maximal Curves&quot; </td>
        </tr>
        <tr valign="top">
          <td width="70">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="160">&nbsp;</td>
          <!--<td align="right" width="200"><a href="seminars-09-RonKerman.php">More Info.</a></td>-->
        </tr>
        <tr valign="top">
          <td colspan="4"><hr /></td>
        </tr>
      </table>
      <p align="justify"><span class="headsub1"><a name="2008" id="2008"></a>2008</span> </p>
      <blockquote>
        <table border="0" cellpadding="2" cellspacing="0" class="tbldata">
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
              <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
              <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
              <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">30.12.2008</td>
              <td width="70">&nbsp;</td>
              <td width="160">K. R. Parthasarathy, Indian Statistical Institute, Delhi</td>
              <td width="200">Estimation Of Density Operators in finite level Quantum Systems</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars-08-KRP2.php">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">24.12.2008</td>
              <td width="70">&nbsp;</td>
              <td width="160">G. Pisier, University  Of Paris 6 and Texas A &amp; M University</td>
              <td width="200">Complex                           Interpolation for Banach Spaces of Operators</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars-08-GPisier.php">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">23.12.2008<br />
                26.12.2008</td>
              <td width="70">&nbsp;</td>
              <td width="160">K. R. Parthasarathy, Indian Statistical Institute, Delhi</td>
              <td width="200">Comparitive description of Circuits in Classical and Quantum Computers</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars-08-KRP1.php">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">23.12.2008</td>
              <td width="70">&nbsp;</td>
              <td width="160">J. Demailly, Institute Fourier France</td>
              <td width="200">Approximation of currents and applications to complex geometry</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars-08-Demailly.php">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">22.08.2008<br />
                27.08.2008</td>
              <td width="70">&nbsp;</td>
              <td width="160">Ali Baklouti, Department of Mathematics, University of&nbsp;                           Sfax, Tunisia</td>
              <td width="200">Some uncertainty principles on solvable Lie groups</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars-08-Ali.php">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">22.08.2008</td>
              <td width="70">&nbsp;</td>
              <td width="160">Marius Tucsnak, Nancy Universites-IECN INRIA - CORIDA</td>
              <td width="200">Self-Propelled Motions of Solids in Viscous Fluids:  Mathematical Analysis and Control Problems</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars-08-MT.php">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
        <table width="500" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td><span class="headsub1"><a name="2007" id="2007"></a>2007</span></td>
            <td align="right"><table border="0" cellpadding="2" cellspacing="0" class="tbldata">
              <tr>
                <td><a href="#top">Go Top</a></td>
              </tr>
            </table></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
              <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
              <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
              <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">11.01.2007</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Sarika Jalan<br />
                Max Planck Institute for Mathematics in Science (MPI-MiS<br />
                Germany</td>
              <td width="200">Stochasticity in Complex Networks: A Random Matrix Analysis</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/sarika.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
        <table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="headsub1"><a name="2006" id="2006"></a>2006</span></td>
            <td align="right"><table border="0" cellpadding="2" cellspacing="0" class="tbldata">
              <tr>
                <td><a href="#top">Go Top</a></td>
              </tr>
            </table></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
              <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
              <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
              <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">18.08.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. R. L. Karandikar<br />
                Cranes Software International Limited,<br />
                Bangalore </td>
              <td width="200"> Martingale Problem to Mancov Processes </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/karandikar.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">17.08.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. N. Hemachandra<br />
                Industrial Engg.and Operations Research<br />
                IIT Bombay, Mumbai </td>
              <td width="200"> Sensitivity analysis and optimal ultimately stationery policiesin Markov decision </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/hemachandra.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">11.08.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. K. B. Athreya<br />
                Iowa State University,USA </td>
              <td width="200"> Growth rates for random graphs </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/athreya.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">25.07.2006</td>
              <td width="70">11.00 am</td>
              <td width="160">Dr. Alpan Raval<br />
                Keek Graduate Institute </td>
              <td width="200">Gene function prediction and evolutionary variability from interactome analysis </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/alpan.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
          </tbody>
          <tbody>
            <tr valign="top">
              <td width="70">07.07.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">David Wilson<br />
                Microsoft Research, USA </td>
              <td width="200">Mixing times of lozenge tiling and card shuffling Markov chains </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/david.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
          </tbody>
          <tbody>
            <tr valign="top">
              <td width="70">24.04.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Divakar Viswanath<br />
                Department of Mathematics  						University of Michigan  						Ann Arbor, MI 48109, U.S.A. </td>
              <td width="200"> Strange attractors from Lorenz to turbulence </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/divakar.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">18.04.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. B. Mayil Vaganan<br />
                Department of Mathematics  						Madurai Kamaraj University,  						Madurai, Tamil Nadu. </td>
              <td width="200"> Exact Linearization of Burgers Equation with Linear Damping and  Variable Viscosity by the modified methods of Lie and Backlund </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/mayil.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">17.01.2006</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Ajit K. Kembhavi<br />
                Inter-University Centre for Astronomy and Astrophysics (IUCAA),  						University Campus, Pune </td>
              <td width="200"> Virtual Observatories - A New Data Paradigm </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/sem-kembh.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">03.01.2006</td>
              <td width="70">3.30 pm</td>
              <td width="160">Prof. J&uuml;rgen Kurths<br />
                Interdisciplinary Centre for Dynamics of   						Complex Systems and Institute Physics,   						Potsdam University, Germany </td>
              <td width="200">Synchronization: A Universal Concept in Nonlinear </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/sem-kurths.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
        <table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="headsub1"><a name="2005" id="2005"></a>2005</span></td>
            <td align="right"><table border="0" cellpadding="2" cellspacing="0" class="tbldata">
              <tr>
                <td><a href="#top">Go Top</a></td>
              </tr>
            </table></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
              <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
              <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
              <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">28.08.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Thangadurai<br />
                School of Mathematics<br />
                Harish Chandra Research Institute, Allahabad </td>
              <td width="200">Discriminants and Quadratic Number Fields </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/sem-thanga.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">22.08.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Thangadurai<br />
                School of Mathematics<br />
                Harish Chandra Research Institute, Allahabad </td>
              <td width="200">Prime Numbers and Irreducible Polynomials </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/sem-thanga.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">17.08.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Dr. Deepak Sridhara<br />
                Institut fur Mathematik<br />
                University of Zurich<br /></td>
              <td width="200">Pseudocodewords of LDPC Constraint Graphs and Construction                           of LDPC Codes </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-deepak1.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">27.06.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Krishna B. Athreya<br />
                Visiting Professor<br />
                Department of Mathematics<br />
                IISc., Bangalore<br /></td>
              <td width="200">Entropy maximisation, measure free martingales                           and weak convergence of Gibbs measure</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-athreya.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">02.04.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Dr. Soumyendu Raha<br />
                Super Computer Education and Research Center<br />
                Indian Institute of Science<br />
                Bangalore<br />
                <a href="mailto:raha@serc.iisc.ernet.in">raha@serc.iisc.ernet.in</a></td>
              <td width="200">Computations with Differential-Algebraic Equations</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-raha.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">04.03.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Jayanth R Banavar<br />
                Penn State, USA</td>
              <td width="200">Scaling in ecology</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-banavar3.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">03.03.2005</td>
              <td width="70">2.00 pm</td>
              <td width="160">Prof. Shin-ichi Kurokawa<br />
                Accelerator Laboratory<br />
                KEK, Japan</td>
              <td width="200">The worlds highest luminosity e+e- collider,                             KEKB, and its main achievements in accelerator physics                             and high - energy physics</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">02.03.2005</td>
              <td width="70">4.00 pm</td>
              <td width="200">Prof. Rajeeva L Karandikar<br />
                Indian Statistical Institute, No.7, S J S Sansanwal                             Marg <br />
                New Delhi 110 016 </td>
              <td width="200"><a target="_blank">Popular                             talk on </a> <br />
                <br />
                Opinion poll, exit poll and early seat projection </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-Karandikar2.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">01.03.2005</td>
              <td width="70">4.00 pm</td>
              <td width="200">Prof. Rajeeva L Karandikar<br />
                Indian Statistical Institute, No.7, S J S Sansanwal                             Marg <br />
                New Delhi 110 016 </td>
              <td width="200">Probably Approximately Correct Learning                             with Beta-Mixing In put Sequences</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-Karandikar1.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top"> </tr>
            <tr>
              <td width="70">20.01.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Gerard Iooss<br />
                IUF, INLN UMR CNRS-UNSA 6618 <br />
                1361, route des Lucioles<br />
                06560 Valbonne, France</td>
              <td width="200">Water-waves as a spatial reversible dynamical                             system, infinite depth case (influence of an essential                             spectrum</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-Iooss.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">19.01.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Dr. Ramarathnam Venkatesan<br />
                Microsoft Research </td>
              <td width="200">Towards a Cryptographic approach to signal                             processing: Image Direct infusion in brain tissue: from                             Authentication and the Randlet Transform</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-Ramarathnam1.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">19.01.2005</td>
              <td width="70">2.30 pm</td>
              <td width="160">Dr. Ramarathnam Venkatesan<br />
                Microsoft Research </td>
              <td width="200">Ramanujan Graphs and the Random Reducibility                             of Discrete dynamical system, infinite depth case (influence                             of an Log; Elliptic Curves of the same order</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-Ramarathnam2.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">11.01.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Raghu Raghavan<br />
                President <br />
                Therataxis, Baltimore, USA <br />
                (formerly, Professor of Computer Science and Radiology,                             John Hopkins University, USA)</td>
              <td width="200">Direct infusion in brain tissue: from start                             to finish</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-raghavan2.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">10.01.2005</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Raghu Raghavan<br />
                President <br />
                Therataxis, Baltimore, USA <br />
                (formerly, Professor of Computer Science and Radiology,                             John Hopkins University, USA)</td>
              <td width="200">Jacobi fields, equivalence transformations,                             and pattern formation in biology</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-raghavan1.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
        <table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="headsub1"><a name="2004" id="2004"></a>2004</span></td>
            <td align="right"><table border="0" cellpadding="2" cellspacing="0" class="tbldata">
              <tr>
                <td><a href="#top">Go Top</a></td>
              </tr>
            </table></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
              <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
              <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
              <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">28.06.2004</td>
              <td width="70">11.00 am</td>
              <td width="160">Prof. Jayanth R Banavar<br />
                Penn State, USA</td>
              <td width="200">Macro-ecology: A mathematical perspective</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-banavar.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">28.06.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Wayne Lawton<br />
                Dept. of Mathematics<br />
                National School of Singapore<br />
                <a href="mailto:matwml@nus.edu.sg">matwml@nus.edu.sg</a></td>
              <td width="200">Constrained Approximation</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-lawton.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">23.04.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Dr. Volker Schulz<br />
                FB IV - Mathematics<br />
                University of Trier<br />
                54286 Trier<br />
                Germany<br />
                <a href="mailto:volker.schulz@uni-trier.de">Volker.Schulz@uni-trier.de</a></td>
              <td width="200">Reduced SQP variants for shape optimization</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-schulz3.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">22.04.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Dr. Volker Schulz<br />
                FB IV - Mathematics<br />
                University of Trier<br />
                54286 Trier<br />
                Germany<br />
                <a href="mailto:volker.schulz@uni-trier.de">Volker.Schulz@uni-trier.de</a></td>
              <td width="200">Optimum experimental design</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-schulz2.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">21.04.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. Dr. Volker Schulz<br />
                FB IV - Mathematics<br />
                University of Trier<br />
                54286 Trier<br />
                Germany<br />
                <a href="mailto:volker.schulz@uni-trier.de">Volker.Schulz@uni-trier.de</a></td>
              <td width="200">Parameter estimation in groundwater flow</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-schulz1.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">19.04.2004</td>
              <td width="70">5.15 pm</td>
              <td width="160">Prof. Dr. Biman Nath<br />
                Raman Research Institute<br />
                Bangalore<br />
                <a href="mailto:biman@rri.ernet.in">biman@rri.ernet.in</a></td>
              <td width="200">Lurking between the galaxies<br />
                (Jointly sponsored by the IISc Mathematics Initiative                             (IMI), IISc and the AvH Association, Bangalore) </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200">&nbsp;</td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">19.04.2004</td>
              <td width="70">4.30 pm</td>
              <td width="160">Prof. Dr. Volker Schulz<br />
                FB IV - Mathematics<br />
                University of Trier<br />
                54286 Trier<br />
                Germany<br />
                <a href="mailto:volker.schulz@uni-trier.de">Volker.Schulz@uni-trier.de</a></td>
              <td width="200">Perspectives in Scientific Computation<br />
                (Jointly sponsored by the IISc Mathematics Initiative                             (IMI), IISc and the AvH Association, Bangalore)</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200">&nbsp;</td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">02.04.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Dr. Soumyendu Raha<br />
                Supercomputer and Research Centre<br />
                Indian Institute of Science<br />
                Bangalore - 12.<br />
                <a href="mailto:raha@serc.iisc.ernet.in">raha@serc.iisc.ernet.in</a></td>
              <td width="200">Computations with Differential-Algebraic                             Equations</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-raha.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">18.03.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Prof. G. Meyer<br />
                School of Mathematics<br />
                Georgia Institute of Technology<br />
                Atlanta, GA 30332-0160<br />
                USA<br />
                <a href="mailto:meyer@math.gatech.edu">meyer@math.gatech.edu</a></td>
              <td width="200">The Numerics of Pricing Equity options</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-meyer.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">12.03.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Dr. Srikanth K. Iyer<br />
                Dept. of Mathematics<br />
                Indian Institute of Technology, Kanpur<br />
                <a href="mailto:skiyer@iitk.ac.in">skiyer@iitk.ac.in</a></td>
              <td width="200">Exponential Changes of Measure for Super                             Brownian Motion and Feller Diffusion</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-iyer.pdf" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">27.02.2004</td>
              <td width="70">4.00 pm</td>
              <td width="160">Dr. Deepak Sridhara<br />
                Research Associate<br />
                Dept. of Mathematics<br />
                IISc., Bangalore - 12<br />
                <a href="mailto:dsridhar@math.iisc.ernet.in">dsridhar@math.iisc.ernet.in</a></td>
              <td width="200">Codes over Graphs and Iterative Decoding </td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-sridhara.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
        <table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="headsub1"><a name="2003" id="2003"></a>2003</span></td>
            <td align="right"><table border="0" cellpadding="2" cellspacing="0" class="tbldata">
              <tr>
                <td><a href="#top">Go Top</a></td>
              </tr>
            </table></td>
          </tr>
        </table>
        <p class="headsub1">&nbsp;</p>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td bgcolor="#e1e1e1" width="70"><strong>Date</strong></td>
              <td bgcolor="#e1e1e1" width="70"><strong>Time</strong></td>
              <td bgcolor="#e1e1e1" width="160"><strong>Speaker</strong></td>
              <td bgcolor="#e1e1e1" width="200"><strong>Topic</strong></td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellpadding="5" cellspacing="0" width="500">
          <tbody>
            <tr valign="top">
              <td width="70">22.12.2003</td>
              <td width="70">4.30 pm</td>
              <td width="160">Prof. Uriel Frisch Laboratoire G.D Cassini                             Observatoire de la Cote d'Azur NICE, FRANCE <a href="mailto:uriel@obs-nice.fr">uriel@obs-nice.fr</a></td>
              <td width="200">The analytic structure of Euler flow.</td>
            </tr>
            <tr valign="top">
              <td width="70">&nbsp;</td>
              <td width="70">&nbsp;</td>
              <td width="160">&nbsp;</td>
              <td align="right" width="200"><a href="seminars/abs-sem-frisch.htm" target="_blank">More Info.</a></td>
            </tr>
            <tr valign="top">
              <td colspan="4"><hr /></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
      </blockquote>
      <p align="justify">&nbsp;</p>
      <p align="justify">&nbsp;</p>
      <p align="justify"></p>
      <p align="justify">&nbsp;</p>
      <p align="justify">&nbsp;</p>
      <p align="justify">&nbsp;</p>
      <p align="justify">&nbsp;</p></td>
  </tr>
</table>
<br />
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="25" align="absmiddle" /><a href="index.php">Home</a> | <a href="contact.php">Contact</a> | <a href="http://www.iisc.ernet.in" target="_blank">About IISc</a></td>
    <td align="right" valign="top" background="images/div-horz-gray.jpg">&nbsp;</td>
  </tr>
</table>
</body>
</html>
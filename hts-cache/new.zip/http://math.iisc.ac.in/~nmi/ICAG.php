<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NMI - National Mathematics Initiative</title>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
<link href="scripts/imi.css" rel="stylesheet" type="text/css" />
<!-- Form Validation Assets Begin -->
<link rel="stylesheet" type="text/css" media="screen" href="scripts/screen.css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="lib/jquery.metadata.js" type="text/javascript"></script>
<script src="scripts/jquery.validate.js" type="text/javascript"></script>
<script src="lib/cmxforms.js" type="text/javascript"></script>
<style type="text/css">
.cmxform fieldset p.error label {
	color: red;
}
div.container {
	background-color: #eee;
	border: 1px solid red;
	margin: 5px;
	padding: 5px;
}
div.container ol li {
	list-style-type: disc;
	margin-left: 20px;
}
div.container {
	display: none
}
.container label.error {
	display: inline;
}
form.cmxform {
}
form.cmxform label.error {
	display: block;
	margin-left: 1em;
	width: auto;
}
</style>
<script type="text/javascript">
// only for demo purposes
//$.validator.setDefaults({
//	submitHandler: function() {
//		alert("submitted! (skipping validation for cancel button)");
//	}
//});

$().ready(function() {
	$("#RFP").validate({
		errorLabelContainer: $("#RFP div.error")
	});
	
	var container = $('div.container');
	// validate the form when it is submitted	
	$(".cancel").click(function() {
		validator.resetForm();
	});
	

});
</script>
<!-- Form Valiation Assets End -->
</head>
<body onload="MM_preloadImages('images/lnk-aboutimi1.jpg','images/lnk-seminars1.jpg','images/lnk-thematicprog2.jpg','images/lnk-thematicprog1.jpg','images/lnk-phdprog1.jpg','images/lnk-requestforpart1.jpg','images/lnk-visitorinfo1.jpg','images/lnk-fundingagencies1.jpg','images/lnk-contact1.jpg')">
<a name="top" id="top"></a>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;&nbsp;
      <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = '<? print date("F d, Y H:i:s", time())?>' //PHP method of getting server date
var currenttime = '<? print date("F d, Y H:i:s")?>' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime"></span>&nbsp;</td>
    <td align="right"><a href="index.php"><img src="images/icon-home.jpg" width="27" height="25" border="0" align="absmiddle" /></a>&nbsp;<a href="index.php">Home</a>&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><img src="images/spacer.gif" width="50" height="10" /></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="aboutimi-overview.php" target="_top" onclick="MM_nbGroup('down','group1','aboutimi','images/lnk-aboutimi1.jpg',1)" onmouseover="MM_nbGroup('over','aboutimi','images/lnk-aboutimi1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-aboutimi.jpg" alt="About NMI" name="aboutimi" width="108" height="31" border="0" id="aboutimi" onload="" /></a></td>
    <td><a href="atp.php" target="_top" onclick="MM_nbGroup('down','group1','thematicprogrammes','images/lnk-thematicprog1.jpg',1)" onmouseover="MM_nbGroup('over','thematicprogrammes','images/lnk-thematicprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-thematicprog.jpg" alt="Thematic Programmes" name="thematicprogrammes" width="120" height="31" border="0" id="thematicprogrammes" onload="" /></a></td>
    <td><a href="otherevents.php" target="_top" onclick="MM_nbGroup('down','group1','otherevents','images/lnk-otherevents1.jpg',1)" onmouseover="MM_nbGroup('over','otherevents','images/lnk-otherevents1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-otherevents.jpg" alt="Other Events" name="otherevents" width="107" height="31" border="0" id="otherevents" onload="" /></a></td>
    <td><a href="PhD Home.php" target="_top" onclick="MM_nbGroup('down','group1','phdprogrammes','images/lnk-phdprog1.jpg',1)" onmouseover="MM_nbGroup('over','phdprogrammes','images/lnk-phdprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-phdprog.jpg" alt="Ph.d Programmes" name="phdprogrammes" width="133" height="31" border="0" id="phdprogrammes" onload="" /></a></td>
    <td><a href="atp-requestforparticipation.php" target="_top" onclick="MM_nbGroup('down','group1','requestforpart','images/lnk-requestforpart1.jpg',1)" onmouseover="MM_nbGroup('over','requestforpart','images/lnk-requestforpart1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-requestforpart.jpg" alt="Request for Participation" name="requestforpart" width="110" height="31" border="0" id="requestforpart" onload="" /></a></td>
    <td><a href="visitorinfo.php" target="_top" onclick="MM_nbGroup('down','group1','visitorinfo','images/lnk-visitorinfo1.jpg',1)" onmouseover="MM_nbGroup('over','visitorinfo','images/lnk-visitorinfo1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-visitorinfo.jpg" alt="Visitor and Local Information" name="visitorinfo" width="112" height="31" border="0" id="visitorinfo" onload="" /></a></td>
    <td><a href="fundingagencies.php" target="_top" onclick="MM_nbGroup('down','group1','fundingagencies','images/lnk-fundingagencies1.jpg',1)" onmouseover="MM_nbGroup('over','fundingagencies','images/lnk-fundingagencies1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-fundingagencies.jpg" alt="Funding Agencies" name="fundingagencies" width="81" height="31" border="0" id="fundingagencies" onload="" /></a></td>
    <td><a href="contact.php" target="_top" onclick="MM_nbGroup('down','group1','contact','images/lnk-contact1.jpg',1)" onmouseover="MM_nbGroup('over','contact','images/lnk-contact1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-contact.jpg" alt="Contact" name="contact" width="82" height="31" border="0" id="contact" onload="" /></a></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
  <tr>
    <td><img src="images/bannerimg-main.jpg" alt="National Mathematics Initiative (NMI)" width="880" height="190" /></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
</table>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3" background="images/div-horz-header.jpg"><img src="images/spacer.gif" alt="" width="10" height="35" align="absmiddle" /><span class="headmain">OTHER EVENTS</span><span class="head1"><span class="headmain"> </span><img src="images/spacer.gif" alt="" width="5" height="35" align="absmiddle" /></span></td>
  </tr>
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td width="650" align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
  </tr>
  <tr>
    <td width="220" align="left" valign="top"><table width="220" border="0" cellspacing="0" cellpadding="5">
      
      
       <!--
      <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="atp-requestforparticipation.php" align="justify">Request for Participation</a></li>
        </ul></td>
      </tr>
	  -->
	  <!--
	  <tr>
	          <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="PTAOrgCom.php" align="justify">Organizing Committee</a> </li>
        </ul></td>
      </tr>
	 <tr>
	          <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="MFWS.php" align="justify">Workshop on Mathematical Finance</a> </li>
        </ul></td>
      </tr>
	   <tr>
         <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><a href="LTPWS.php" align="justify">Workshop on Limit Theorems in Probability</a></li>
        </ul></td>
      </tr>
	   <tr>
         <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><a href="LTPConf.php" align="justify">Conference on Limit Theorems in Probability</a></li>
        </ul></td>
      </tr>
	  <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><a href="SPEWS.php" align="justify">Workshop and Conference on Stochastic Processes in Engineering </a></li>
        </ul></td>
      </tr>
	   <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="NDPWS.php" align="justify"> Workshop and Conference on New Directions in Probability</a></li>
        </ul></td>
      </tr>
	   <tr>
        <!--<td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><!--<a href="MEWS.php" align="justify">--><!--<a href="http://www.icts.res.in/program/NSEECS">ICTS Workshop on Network Science in Electrical Engineering and Computer Science</a></li>
        </ul></td>
      </tr>
	  <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="SNWS.php" align="justify">Workshop on Social Networks  </a></li>
        </ul></td>
      </tr>
	   <tr>
       
      </tr>
	   <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="NBSSEWS.php" align="justify">School on Networks in Biology, Social Science and Engineering</a></li>
        </ul></td>
      </tr>
	    <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="NBSSEConf.php" align="justify">International Conference on Networks in Biology, Social Science and Engineering</a></li>
        </ul></td>
      </tr>-->
      </table></td>
    <td width="10" align="left" valign="top" background="images/div-vert-links.jpg"><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /></td>
    <td align="left" valign="top"><table width="95%" border="0" cellspacing="0" cellpadding="5">
                <tr valign="top"> 
                  <td><p><strong>PAST WORKSHOPS/CONFERENCES</strong></p>
<p>&nbsp;</p>
                    <p align="justify" class="headsub1">2012 - 2013<br />
                      <br /></p>
                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                      <tbody>
                        <tr valign="top">
                          <td colspan="2"><p><strong>
International Conference on Algebraic Geometry<br />
                                <br />
								
</strong><strong>December 01 - 03, 2012</strong><br /> <br /> 


<tr>                        </tr>
                      </tbody>
                    </table>
                    <table border="0" cellpadding="0" cellspacing="0" height="59" width="100%">
                      <tbody>
                        <tr valign="top">
                          <td height="57" width="50%"><ul>
                            <!-- <li> <a href="atp-0910-resource1.php"> Resource Persons</a></li>-->
                             <li><a href="ICAGConvener.php">Convener </a></li>
							 <li><a href="ICAGOrgComm.php">Organizing Committee </a></li>
							 <li><a href="ICAGInvitedSpeakers.php">Invited Speakers </a></li>
							 <li> <a href="downloads/ICAG_2012.pdf"> 
							Programme Schedule</a></li>
							<!--<li> <a href="downloads/SNWSSelected_Participants.pdf">SELECTED PARTICIPANTS LIST</a></li>-->
                            <!--<li> <a href="downloads/PS PDE Aug workshop.pdf"> 
							Programme Schedule</a></li>-->
                           <!-- <li><a href="downloads/PS_CANE.pdf">Tentative Programme Schedule</a></li>-->
							                          </ul></td>
                          <td height="57" width="50%">
                              <li> <a href="ICAGVenue.php"> Venue</a></li>	
							 <li><a href="http://imi.appzone.co.in/">Request for Participation</a></li>
							  <li> <a href="ICAGdeadline.php">Deadline</a></li>
							  					  </td>
                        </tr>
                        <tr valign="top">
                          <td colspan="2" height="2"><hr />                          </td>
                        </tr>
                      </tbody>
                    
        
                    </table>
                    <br/><br/>
                    <div align="justify">Prof. M. S. Narasimhan completed 80 years recently. As he is one of the
pre-eminent mathematicians of the country, it was felt that an
International Conference on Algebraic Geometry should be organized
celebrating this occasion. The conference will feature talks by
well-known mathematicians on several areas that Prof. Narasimhan has
made deep contributions to.<br/><br/>

Prof. Narasimhan's work has strongly influenced several areas of
Algebraic Geometry, Differential Geometry, Representation Theory of
Lie groups and Partial Differential Equations. He pioneered the
development of the theory of moduli spaces of vector bundles on
curves and higher dimensional projective varieties with C.S.
Seshadri and S. Ramanan. His work with G. Harder on canonical
filtrations on algebraic vector bundles and with K Okamoto on the
concrete realisations of discrete series representations of
Harish-Chandra have been highly influential in the subject. Several
distinguished Indian mathematicians were his former research
students.<br/><br/>

Prof. Narasimhan has played a key role in the development of
Mathematics in India and in developing countries by influencing
several mathematicians and by creating structures for promoting
research in Mathematics. He was the founding-Chairman of the NBHM.
He was a member of the Executive Committee of International
Mathematical Union (IMU) from 1982 to 1986 and President of the
Commission on Development and Exchange of IMU (1986-94). As head
of the mathematics group at ICTP for several years, he has been
instrumental in inculcating the research culture among mathematicians
from many developing countries.<br/>
  <br/></div>
  
  <tr>                        </tr>
                      </tbody>
                    </table>
                    <table border="0" cellpadding="0" cellspacing="0" height="59" width="100%">
                      <tbody>
                        <tr valign="top">
                          <td height="57" width="50%"><ul>
  <strong>SPONSORED BY</strong><br />
  <li>Chennai Mathematical Institute, Chennai</li>
  <li>Institute of Mathematical Sciences, Chennai</li>
  <li>IISc Mathematics Initiative, Indian Institute of Science, Bangalore</li>
  <li>Indian Statistical Institute, Kolkata</li>
  <li>Microsoft Research India, Bangalore</li>
  <li>National Board for Higher Mathematics, Mumbai</li>
  <li>TIFR Centre for Applicable Mathematics, Bangalore</li>
  <li>TIFR Mumbai, Mumbai</li>
  
                                <br />
								
                    <!--
                    <p align="justify">The workshop will provide an in-depth introduction to modeling and
                      analysis of social networks. By bringing together
                      social scientists, physicists, mathematicians and computer scientists
                      working on different aspects of social networks, the meeting aims to
                      foster cross-disciplinary interactions and long-term collaborations.                    </p>
                    <div align="justify"><br/>
                    </div>
                    <p align="justify">The event is being jointly organized by the Institute of Mathematical
                      Sciences (IMSc), Indian Institute of Technology-Madras (IIT-M) and the
                      IISc Mathematics Initiative (IMI).</p>
                    <p align="center"><br/>
                      <br/>
					<!--  <a href="http://imi.appzone.co.in/"><strong>REQUEST FOR PARTICIPATION</strong></a>-->
				<!--	<a href="downloads/SNWSSelected_Participants.pdf"><strong>SELECTED PARTICIPANTS LIST</strong></a>
                      <br/>
					  -->
					  
                      </li>
                      </ul>
                      <br />
                      </li>
                      </ol>
                    </p>
                    </p>
                    <p align="justify">&nbsp;</p>
                    <p align="justify">&nbsp;</p>
                  <p align="justify">&nbsp;</p></td>
  </tr>
              </table></td>
  </tr>
</table>
<br />
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="25" align="absmiddle" /><a href="index.php">Home</a> | <a href="contact.php">Contact</a> | <a href="http://www.iisc.ernet.in" target="_blank">About IISc</a></td>
    <td align="right" valign="top" background="images/div-horz-gray.jpg">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NMI - National Mathematics Initiative</title>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
<link href="scripts/imi.css" rel="stylesheet" type="text/css" />
<!-- Form Validation Assets Begin -->
<link rel="stylesheet" type="text/css" media="screen" href="scripts/screen.css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="lib/jquery.metadata.js" type="text/javascript"></script>
<script src="scripts/jquery.validate.js" type="text/javascript"></script>
<script src="lib/cmxforms.js" type="text/javascript"></script>
<style type="text/css">
.cmxform fieldset p.error label {
	color: red;
}
div.container {
	background-color: #eee;
	border: 1px solid red;
	margin: 5px;
	padding: 5px;
}
div.container ol li {
	list-style-type: disc;
	margin-left: 20px;
}
div.container {
	display: none
}
.container label.error {
	display: inline;
}
form.cmxform {
}
form.cmxform label.error {
	display: block;
	margin-left: 1em;
	width: auto;
}
</style>
<script type="text/javascript">
// only for demo purposes
//$.validator.setDefaults({
//	submitHandler: function() {
//		alert("submitted! (skipping validation for cancel button)");
//	}
//});

$().ready(function() {
	$("#RFP").validate({
		errorLabelContainer: $("#RFP div.error")
	});
	
	var container = $('div.container');
	// validate the form when it is submitted	
	$(".cancel").click(function() {
		validator.resetForm();
	});
	

});
</script>
<!-- Form Valiation Assets End -->
</head>
<body onload="MM_preloadImages('images/lnk-aboutimi1.jpg','images/lnk-thematicprog2.jpg','images/lnk-thematicprog1.jpg','images/lnk-phdprog1.jpg','images/lnk-requestforpart1.jpg','images/lnk-visitorinfo1.jpg','images/lnk-fundingagencies1.jpg','images/lnk-contact1.jpg','images/lnk-otherevents1.jpg')">
<a name="top" id="top"></a>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;&nbsp;
      <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = '<? print date("F d, Y H:i:s", time())?>' //PHP method of getting server date
var currenttime = '<? print date("F d, Y H:i:s")?>' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime"></span>&nbsp;</td>
    <td align="right"><a href="index.php"><img src="images/icon-home.jpg" width="27" height="25" border="0" align="absmiddle" /></a>&nbsp;<a href="index.php">Home</a>&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><img src="images/spacer.gif" width="50" height="10" /></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="aboutimi-overview.php" target="_top" onclick="MM_nbGroup('down','group1','aboutimi','images/lnk-aboutimi1.jpg',1)" onmouseover="MM_nbGroup('over','aboutimi','images/lnk-aboutimi1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-aboutimi.jpg" alt="About NMI" name="aboutimi" width="108" height="31" border="0" id="aboutimi" onload="" /></a></td>
    <td><a href="atp.php" target="_top" onclick="MM_nbGroup('down','group1','thematicprogrammes','images/lnk-thematicprog1.jpg',1)" onmouseover="MM_nbGroup('over','thematicprogrammes','images/lnk-thematicprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-thematicprog.jpg" alt="Thematic Programmes" name="thematicprogrammes" width="120" height="31" border="0" id="thematicprogrammes" onload="" /></a></td>
    <td><a href="otherevents.php" target="_top" onclick="MM_nbGroup('down','group1','otherevents','images/lnk-otherevents1.jpg',1)" onmouseover="MM_nbGroup('over','otherevents','images/lnk-otherevents1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-otherevents.jpg" alt="Other Events" name="otherevents" width="107" height="31" border="0" id="otherevents" onload="" /></a></td>
    <td><a href="PhD Home.php" target="_top" onclick="MM_nbGroup('down','group1','phdprogrammes','images/lnk-phdprog1.jpg',1)" onmouseover="MM_nbGroup('over','phdprogrammes','images/lnk-phdprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-phdprog.jpg" alt="Ph.d Programmes" name="phdprogrammes" width="133" height="31" border="0" id="phdprogrammes" onload="" /></a></td>
    <td><a href="atp-requestforparticipation.php" target="_top" onclick="MM_nbGroup('down','group1','requestforpart','images/lnk-requestforpart1.jpg',1)" onmouseover="MM_nbGroup('over','requestforpart','images/lnk-requestforpart1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-requestforpart.jpg" alt="Request for Participation" name="requestforpart" width="110" height="31" border="0" id="requestforpart" onload="" /></a></td>
    <td><a href="visitorinfo.php" target="_top" onclick="MM_nbGroup('down','group1','visitorinfo','images/lnk-visitorinfo1.jpg',1)" onmouseover="MM_nbGroup('over','visitorinfo','images/lnk-visitorinfo1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-visitorinfo.jpg" alt="Visitor and Local Information" name="visitorinfo" width="112" height="31" border="0" id="visitorinfo" onload="" /></a></td>
    <td><a href="fundingagencies.php" target="_top" onclick="MM_nbGroup('down','group1','fundingagencies','images/lnk-fundingagencies1.jpg',1)" onmouseover="MM_nbGroup('over','fundingagencies','images/lnk-fundingagencies1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-fundingagencies.jpg" alt="Funding Agencies" name="fundingagencies" width="81" height="31" border="0" id="fundingagencies" onload="" /></a></td>
    <td><a href="contact.php" target="_top" onclick="MM_nbGroup('down','group1','contact','images/lnk-contact1.jpg',1)" onmouseover="MM_nbGroup('over','contact','images/lnk-contact1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-contact.jpg" alt="Contact" name="contact" width="82" height="31" border="0" id="contact" onload="" /></a></td>
  </tr>
</table>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
  <tr>
    <td><img src="images/bannerimg-main-phd.jpg" alt="National Mathematics Initiative (NMI)" width="880" height="190" /></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
</table><table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3" background="images/div-horz-header.jpg"><img src="images/spacer.gif" width="10" height="35" align="absmiddle" /><span class="headmain">Ph.D PROGRAMME </span><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /></td>
  </tr>
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td width="650" align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
  </tr>
  <tr>
    <td width="220" align="left" valign="top"><table width="220" border="0" cellspacing="0" cellpadding="5">
      <tr>
        <td height="52">&raquo; <a href="PhD Home.php">Overview</a></td>
      </tr>
      <tr>
        <td height="45" background="images/panel-bak-div-horz.jpg">&raquo; <a href="PhD Convener.php">Convener</a> </td>
      </tr>
      
      <tr>
        <td height="47" background="images/panel-bak-div-horz.jpg"><p>&raquo; Participating Faculty</a></p>
          </td>
      </tr>
	  <tr>
        <td height="47" background="images/panel-bak-div-horz.jpg"><p>&raquo; <a href="IntwProcess.php">Interview Process <br />
                            </a></p>         </td>
      </tr>
      <tr>
         <td height="47" background="images/panel-bak-div-horz.jpg"><p>&raquo; <a href="PhD Students.php">Students under Interdisiplinary <br />
              <span class="style1">&nbsp; &nbsp;</span>Mathematical Sciences <br /> 
              <span class="style1">&nbsp; &nbsp;</span>Programme</a></p>         </td>
      </tr>
      <tr>
        <td height="47" background="images/panel-bak-div-horz.jpg">&raquo; <a href="PhD Contacts.php">Contacts</a></td>
      </tr>
    </table></td>
    <td width="10" align="left" valign="top" background="images/div-vert-links.jpg"><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /></td>
    <td align="left" valign="top"><p align="justify">&nbsp;</p>
      <p align="justify"><span style="font-weight: bold">Participating Faculty:</span> <br />
        Each selected students will be 
        assigned (based on their interest) to two of the 
        following faculty members from two different 
        Departments.</p>
      <ul>
	  <li>Dr. Shivani Agarwal<br />
          Department of Computer Science & Automation
<br />
          E-mail : <a href="mailto:shivani@csa.iisc.ernet.in">shivani@csa.iisc.ernet.in</a><br />
          <br />
        <li>Prof. G. K. Ananthasuresh<br />
          Department of Mechanical Engineering<br />
          E-mail : <a href="mailto:suresh@mecheng.iisc.ernet.in">suresh@mecheng.iisc.ernet.in</a><br />
          <br />
        </li>
		<li>Prof. S. P. Arun<br />
          Center for Neuroscience<br />
          E-mail : <a href="mailto:sparun@cns.iisc.ernet.in
">sparun@cns.iisc.ernet.in
</a><br />
          <br />
        </li>
        <li> Prof. Shalabh Bhatnagar<br />
          Department of Computer Science &amp; Automation<br />
          E-mail : <a href="mailto:shalabh@csa.iisc.ernet.in">shalabh@csa.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Chiranjib Bhattacharyya<br />
          Department of Computer Science &amp; Automation<br />
          E-mail : <a href="mailto:chiru@csa.iisc.ernet.in">chiru@csa.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Nagasuma Chandra<br />
          Supercomputer Education and Research Centre<br />
          E-mail : <a href="mailto:nchandra@serc.iisc.ernet.in">nchandra@serc.iisc.ernet.in</a><br />
          <br />
        </li>
       <!-- <li> Prof. Anindya Chatterjee<br />
          Department of Mechanical Engineering<br />
          E-mail : <a href="mailto:anindya@mecheng.iisc.ernet.in">anindya@mecheng.iisc.ernet.in</a><br />
          <br />
        </li>-->
		<li> Prof. Kunal N. Chaudhury<br />
          Department of Electrical Engineering<br />
          E-mail : <a href="mailto:kunal@ee.iisc.ernet.in">kunal@ee.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Arnab Rai Choudhuri<br />
          Department of Physics <br />
          E-mail :<a href="mailto:arnab@physics.iisc.ernet.in">arnab@physics.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Basudeb Datta<br />
          Department of Mathematics <br />
          E-mail :<a href="mailto:dattab@math.iisc.ernet.in">dattab@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Narendra M. Dixit<br />
          Department of Chemical Engineering<br />
          E-mail: <a href="mailto:narendra@chemeng.iisc.ernet.in">narendra@chemeng.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Siddhartha Gadgil<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:gadgil@math.iisc.ernet.in">gadgil@math.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Sashikumaar Ganesan<br />
          Supercomputer and Education Research Centre<br />
          E-mail : <a href="mailto:sashi@serc.iisc.in">sashi@serc.iisc.in</a><br />
          <br />
        </li>
        <li> Prof. Debasish Ghose<br />
          Department of Aerospace Engineering<br />
          E-mail : <a href="mailto:dghose@aero.iisc.ernet.in">dghose@aero.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Debraj Ghosh<br />
          Department of Civil Engineering<br />
          E-mail : <a href="mailto:dghosh@civil.iisc.ernet.in">dghosh@civil.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Mrinal K. Ghosh<br />
          Department of Mathematics <br />
          E-mail : <a href="mailto:mkg@math.iisc.ernet.in">mkg@math.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Thirupathi Gudi<br />
          Department of Mathematics <br />
          E-mail : <a href="mailto:gudi@math.iisc.ernet.in">gudi@math.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Vishwesha Guttal<br />
          Department of Center for Ecological Sciences <br />
          E-mail : <a href="mailto: guttal@ces.iisc.ernet.in">guttal@ces.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Srikanth K. Iyer<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:skiyer@math.iisc.ernet.in">skiyer@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li>Prof. H S Jamadagni<br />
Department of Electronic Systems Engineering<br />
E-mail :<a href="mailto:hsjam@cedt.iisc.ernet.in">hsjam@cedt.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. P. Vijay Kumar<br />
          Department of Electrical and Communication Engineering<br />
          E-mail : <a href="mailto:vijay@ece.iisc.ernet.in">vijay@ece.iisc.ernet.in</a> <br />
          <br />
        </li>
        <li> Prof. C. E. Veni Madhavan<br />
          Department of Computer Science &amp; Automation<br />
          E-mail : <a href="mailto:cevm@csa.iisc.ernet.in">cevm@csa.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Prabal K. Maiti<br />
          Department of Physics<br />
          E-mail : <a href="mailto:maiti@physics.iisc.ernet.in">maiti@physics.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Rina Maiti<br />
          Centre for Product Design and Manufacturing<br />
          Email : <a href="mailto:rmaiti@cpdm.iisc.ernet.in">rmaiti@cpdm.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. C. Mukhopadhyay<br />
          Department of Management Studies <br />
          E-mail : <a href="mailto:cm@mgmt.iisc.ernet.in">cm@mgmt.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Dr. Aditya Murthy<br />
          Centre For Neuroscience<br />
          E-mail : <a href="mailto:aditya@cns.iisc.ernet.in
">aditya@cns.iisc.ernet.in
</a><br />
          <br />
        </li>
        <li> Prof. A. K. Nandakumaran<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:nands@math.iisc.ernet.in">nands@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li>Prof. S K Nandy<br />
Supercomputer Education and Research Center<br />
E-mail :<a href="mailto:nandy@serc.iisc.ernet.in">nandy@serc.iisc.ernet.in</a>  <br />
          <br />
        </li>
        <li> Prof. Vidyanand Nanjundiah <br />
          Molecular Reproduction, Development &amp; Genetics<br />
          E-mail : <a href="mailto:vidya@ces.iisc.ernet.in">vidya@ces.iisc.ernet.in</a><br />
          <br />
        </li>
		 <li> Prof. Rishikesh Narayanan<br />
          Molecular Biophysics Unit
<br />
          E-mail : <a href="mailto:rishi@mbu.iisc.ernet.in">rishi@mbu.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Vijay Natarajan<br />
          Department of Computer Science and Automation<br />
          E-mail : <a href="mailto:vijayn@csa.iisc.ernet.in">vijayn@csa.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Radhakant Padhi<br />
          Department of Aerospace Engineering<br />
          E-mail : <a href="mailto:padhi@aero.iisc.ernet.in">padhi@aero.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Debnath Pal<br />
          Supercomputer and Education Research Centre<br />
          E-mail : <a href="mailto:dpal@serc.iisc.ernet.in">dpal@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Rahul Pandit <br />
          Department of Physics <br />
          E-mail : <a href="mailto:rahul@physics.iisc.ernet.in">rahul@physics.iisc.ernet.in</a><br />
          <br />
        </li>
        <li>Prof. Dilip P. Patil<br />
          Department of Mathematics<br />
          E-mail :<a href="mailto:patil@math.iisc.ernet.in">patil@math.iisc.ernet.in</a><br />
  <br />
        </li>
        <li> Prof. Phoolan Prasad<br />
          Department of Mathematics <br />
          E-mail : <a href="mailto:prasad@math.iisc.ernet.in">prasad@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Soumyendu Raha<br />
          Supercomputer and Education Research Centre<br />
          E-mail : <a href="mailto:raha@serc.iisc.ernet.in">raha@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. B. Sundar Rajan<br />
          Department of Electrical &amp; Communication Engineering<br />
          E-mail : <a href="mailto:bsrajan@ece.iisc.ernet.in">bsrajan@ece.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Sriram Ramaswamy<br />
          Department of Physics<br />
          E-mail : <a href="mailto:sriram@physics.iisc.ernet.in">sriram@physics.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Dr. Annapoorni Rangarajan<br />
          Molecular Reproduction, Development & Genetics<br />
          E-mail : <a href="mailto:anu@mrdg.iisc.ernet.in">anu@mrdg.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Govindan Rangarajan<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:rangaraj@math.iisc.ernet.in">rangaraj@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. S. V. Raghurama Rao<br />
          Department of Aerospace Engineering<br />
          E-mail : <a href="mailto:raghu@aero.iisc.ernet.in">raghu@aero.iisc.ernet.in</a><br />
          <br />
        </li>
		 <li> Prof. Debasish Roy<br />
          Department of Civil Engineering<br />
          E-mail : <a href="mailto:royd@civil.iisc.ernet.in">royd@civil.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Diptiman Sen<br />
          Centre for High Energy Physics<br />
          E-mail : <a href="mailto:diptiman@cts.iisc.ernet.in">diptiman@cts.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Vinod Sharma<br />
          Department of Electrical Communication Engineering<br />
          E-mail : <a href="mailto:vinod@ece.iisc.ernet.in">vinod@ece.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. S. K. Sikdar<br />
          Molecular Biophysics Unit<br />
          E-mail : <a href="mailto:sks@mbu.iisc.ernet.in">sks@mbu.iisc.ernet.in</a><br />
          <br />
        </li>
        <li>Dr. Shayan Garani Srinivasa<br />
          Department of Electronic Systems Engineering, Room 232<br />
          Phone : +91-80-23600810-Ext 232 (Off)<br />
          Email: <a href="mailto:garani_s@dese.iisc.ernet.in">garani_s@dese.iisc.ernet.in</a><br />          
          <br />
        </li>
        <li> Prof. J. Srinivasan<br />
          Centre for Atmospheric and Oceanic Sciences<br />
          E-mail : <a href="mailto:chairman@cas.iisc.ernet.in">chairman@cas.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. N. Srinivasan<br />
          Molecular Biophysics Unit<br />
          E-mail : <a href="mailto:ns@mbu.iisc.ernet.in">ns@mbu.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. R. M. Vasu<br />
          Department of Instrumentation<br />
          E-mail : <a href="mailto:vasu@isu.iisc.ernet.in">vasu@isu.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Murugesan Venkatapathi <br />
         Supercomputer Education and Research Center<br />
          E-mail : <a href="mailto: murugesh@serc.iisc.ernet.in"> murugesh@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Saraswathi Vishveshwara<br />
          Molecular Biophysics Unit<br />
          E-mail : <a href="mailto:sv@mbu.iisc.ernet.in">sv@mbu.iisc.ernet.in</a> <br />
        <br />
		</li>
		<li> Prof. Phaneendra K. Yalavarthy<br />
          Supercomputer Education and Research Centre<br />
          E-mail : <a href="mailto: phani@serc.iisc.ernet.in"> phani@serc.iisc.ernet.in</a><br />
          <br />
        </li>
    </ul>      <p align="justify"><br />
    </p></td>
  </tr>
</table>
<br />
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="25" align="absmiddle" /><a href="index.php">Home</a> | <a href="contact.php">Contact</a> | <a href="http://www.iisc.ernet.in" target="_blank">About IISc</a></td>
    <td align="right" valign="top" background="images/div-horz-gray.jpg">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NMI - National Mathematics Initiative</title>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
<link href="scripts/imi.css" rel="stylesheet" type="text/css" />
<!-- Form Validation Assets Begin -->
<link rel="stylesheet" type="text/css" media="screen" href="scripts/screen.css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="lib/jquery.metadata.js" type="text/javascript"></script>
<script src="scripts/jquery.validate.js" type="text/javascript"></script>
<script src="lib/cmxforms.js" type="text/javascript"></script>
<style type="text/css">
.cmxform fieldset p.error label {
	color: red;
}
div.container {
	background-color: #eee;
	border: 1px solid red;
	margin: 5px;
	padding: 5px;
}
div.container ol li {
	list-style-type: disc;
	margin-left: 20px;
}
div.container {
	display: none
}
.container label.error {
	display: inline;
}
form.cmxform {
}
form.cmxform label.error {
	display: block;
	margin-left: 1em;
	width: auto;
}
</style>
<script type="text/javascript">
// only for demo purposes
//$.validator.setDefaults({
//	submitHandler: function() {
//		alert("submitted! (skipping validation for cancel button)");
//	}
//});

$().ready(function() {
	$("#RFP").validate({
		errorLabelContainer: $("#RFP div.error")
	});
	
	var container = $('div.container');
	// validate the form when it is submitted	
	$(".cancel").click(function() {
		validator.resetForm();
	});
	

});
</script>
<!-- Form Valiation Assets End -->
</head>
<body onload="MM_preloadImages('images/lnk-aboutimi1.jpg','images/lnk-seminars1.jpg','images/lnk-thematicprog2.jpg','images/lnk-thematicprog1.jpg','images/lnk-phdprog1.jpg','images/lnk-requestforpart1.jpg','images/lnk-visitorinfo1.jpg','images/lnk-fundingagencies1.jpg','images/lnk-contact1.jpg')">
<a name="top" id="top"></a>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;&nbsp;
      <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = '<? print date("F d, Y H:i:s", time())?>' //PHP method of getting server date
var currenttime = '<? print date("F d, Y H:i:s")?>' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime"></span>&nbsp;</td>
    <td align="right"><a href="index.php"><img src="images/icon-home.jpg" width="27" height="25" border="0" align="absmiddle" /></a>&nbsp;<a href="index.php">Home</a>&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><img src="images/spacer.gif" width="50" height="10" /></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="aboutimi-overview.php" target="_top" onclick="MM_nbGroup('down','group1','aboutimi','images/lnk-aboutimi1.jpg',1)" onmouseover="MM_nbGroup('over','aboutimi','images/lnk-aboutimi1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-aboutimi.jpg" alt="About NMI" name="aboutimi" width="108" height="31" border="0" id="aboutimi" onload="" /></a></td>
    <td><a href="atp.php" target="_top" onclick="MM_nbGroup('down','group1','thematicprogrammes','images/lnk-thematicprog1.jpg',1)" onmouseover="MM_nbGroup('over','thematicprogrammes','images/lnk-thematicprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-thematicprog.jpg" alt="Thematic Programmes" name="thematicprogrammes" width="120" height="31" border="0" id="thematicprogrammes" onload="" /></a></td>
    <td><a href="otherevents.php" target="_top" onclick="MM_nbGroup('down','group1','otherevents','images/lnk-otherevents1.jpg',1)" onmouseover="MM_nbGroup('over','otherevents','images/lnk-otherevents1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-otherevents.jpg" alt="Other Events" name="otherevents" width="107" height="31" border="0" id="otherevents" onload="" /></a></td>
    <td><a href="PhD Home.php" target="_top" onclick="MM_nbGroup('down','group1','phdprogrammes','images/lnk-phdprog1.jpg',1)" onmouseover="MM_nbGroup('over','phdprogrammes','images/lnk-phdprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-phdprog.jpg" alt="Ph.d Programmes" name="phdprogrammes" width="133" height="31" border="0" id="phdprogrammes" onload="" /></a></td>
    <td><a href="atp-requestforparticipation.php" target="_top" onclick="MM_nbGroup('down','group1','requestforpart','images/lnk-requestforpart1.jpg',1)" onmouseover="MM_nbGroup('over','requestforpart','images/lnk-requestforpart1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-requestforpart.jpg" alt="Request for Participation" name="requestforpart" width="110" height="31" border="0" id="requestforpart" onload="" /></a></td>
    <td><a href="visitorinfo.php" target="_top" onclick="MM_nbGroup('down','group1','visitorinfo','images/lnk-visitorinfo1.jpg',1)" onmouseover="MM_nbGroup('over','visitorinfo','images/lnk-visitorinfo1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-visitorinfo.jpg" alt="Visitor and Local Information" name="visitorinfo" width="112" height="31" border="0" id="visitorinfo" onload="" /></a></td>
    <td><a href="fundingagencies.php" target="_top" onclick="MM_nbGroup('down','group1','fundingagencies','images/lnk-fundingagencies1.jpg',1)" onmouseover="MM_nbGroup('over','fundingagencies','images/lnk-fundingagencies1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-fundingagencies.jpg" alt="Funding Agencies" name="fundingagencies" width="81" height="31" border="0" id="fundingagencies" onload="" /></a></td>
    <td><a href="contact.php" target="_top" onclick="MM_nbGroup('down','group1','contact','images/lnk-contact1.jpg',1)" onmouseover="MM_nbGroup('over','contact','images/lnk-contact1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-contact.jpg" alt="Contact" name="contact" width="82" height="31" border="0" id="contact" onload="" /></a></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
  <tr>
    <td><img src="images/bannerimg-main.jpg" alt="National Mathematics Initiative (NMI)" width="880" height="190" /></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
</table>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3" background="images/div-horz-header.jpg"><img src="images/spacer.gif" width="10" height="35" align="absmiddle" /><span class="headmain">THEMATIC PROGRAMME </span><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /><span class="head1">&raquo; CURRENT</span></td>
  </tr>
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
    <td width="650" align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="10" align="absmiddle" /></td>
  </tr>
  <tr>
    <td width="220" align="left" valign="top"><table width="220" border="0" cellspacing="0" cellpadding="5">
      
      
     
	    
	  <tr>
	          <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="SDMD.php" align="justify">Static and Dynamic Mechanism Design</a> </li>
        </ul></td>
      </tr>
	  	   <tr>
         <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><a href="netgames.php" align="justify">Networks and Games</a></li>
        </ul></td>
      </tr>
	   <tr>
         <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><a href="GTMD.php" align="justify">Game Theory and Mechanism Design </a></li>
        </ul></td>
      </tr>
	  <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><a href="ICFDGT.php" align="justify">International Conclave on Foundations of Decision and Game Theory</a></li>
        </ul></td>
      </tr>
	   <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul>
            <li class="listing"><a href="GTO_NP.php" align="justify"> Game Theory and Optimization </a></li>
        </ul></td>
      </tr>
	   <tr>
        <td background="images/panel-bak-div-horz.jpg"><ul><li class="listing"><!--<a href="NOML.php"  align="justify">-->Methods for Large Scale Optimization and Robust Optimization</a></li>
        </ul></td>
      </tr>
	   <tr>
        
      </table></td>
    <td width="10" align="left" valign="top" background="images/div-vert-links.jpg"><img src="images/spacer.gif" width="5" height="35" align="absmiddle" /></td>
    <td align="left" valign="top"><table width="95%" border="0" cellspacing="0" cellpadding="5">
                <tr valign="top"> 
                  <td><p align="justify" class="headsub1">2015 - 2016<br />
                      <br />
			 			  
			  <marquee width="140%" scrolldelay="60" loop="-1" direction="left" style="border-style: dotted; border-width: 0px;" onmouseover="this.stop()" onmouseout="this.start()" behaviour="scroll"><p align="center">&nbsp;</p>
			  </br> </marquee>

				  </p>
                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                      <tbody>
                        <tr valign="top">
                          <td colspan="2"><p><strong>International Conclave on Foundations of Decision and Game Theory</strong>
                            
                            <p>&nbsp;  </p>
                            <strong>March 14 - 19, 2016</strong><br />
<br />

<tr>                        </tr>
                      </tbody>
                    </table>
                    <table border="0" cellpadding="0" cellspacing="0" height="59" width="100%">
                      <tbody>
                        <tr valign="top">
                          <td height="57" width="50%"><ul>
                           
                             <li><a href="ICFDGT.php">Nature of the workshop </a></li>
			     <li><a href="http://imi.appzone.co.in/">Online Application</a></li>
			 
							 							  
                          </ul></td>
                          <td height="57" width="50%">
                              <ul>
		                <li><a href="ICFDGT_coordinators.php">Organizing Committee</a></li>
                                <li><a href="ICFDGT_Participants.pdf">List of Selected Participants</a></li>

				</ul>
                             
	  					  </td>
                        </tr>
                        <tr valign="top">
                          <td colspan="2" height="2"><hr />                          </td>
                        </tr>
                      </tbody>
                    
        
                    </table>
					
                    <br/><br/>
                    <div align="justify">
                      <p>Nature of the program:</p> <br />
                      <p align="justify">
Indian Institute of Technology Bombay (IIT-B) and Indira Gandhi Institute
of Devel-opment Research Mumbai (IGIDR) will organize the Conclave in
Mumbai on the broad theme \Foundations of Decision and Game Theory", as
part of the National Mathematics Initiative's Year on \Game Theory and
Optimization" during March 14 - 19, 2016.  This Conclave consists of:
<br><br>
1.  Two Short Courses on \Network Games" to be taught by Professors Sanjiv
Goyal (University of Cambridge) and Sudipta Sarangi (Virginia Tech
University).<br>
2.  Several invited lectures from around the world.
Around 25 participants from among Nationwide application pool comprising
of research scholars and junior faculty broadly working in the area of
Games and Decisions will be selected  to  attend  the  Conclave  as  a 
capacity  building  exercise.   They  are  likely  to  be provided 3-tier
AC return train fare, boarding and lodging.  Selection Committee's
decision would be nal.  We will also have place for at least 50 Mumbai based
participants.  The program will be held in IGIDR.
</p>
                    </div>
                    <p>
				
				</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>Supported by National Mathematics Initiative<br>
                      (Department of Science & Technology, Government of India)<br />
				      <br />
                    </p>
                    <p>&nbsp;</p>
<a href="http://sites.ieee.org/bangalore-sps/"></a><br />
<p align="justify">&nbsp;</p>
                    <p align="justify">&nbsp;</p>
                  <p align="justify">&nbsp;</p></td>
  </tr>
              </table></td>
  </tr>
</table>
<br />
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top" background="images/div-horz-gray.jpg"><img src="images/spacer.gif" width="10" height="25" align="absmiddle" /><a href="index.php">Home</a> | <a href="contact.php">Contact</a> | <a href="http://www.iisc.ernet.in" target="_blank">About IISc</a></td>
    <td align="right" valign="top" background="images/div-horz-gray.jpg">&nbsp;</td>
  </tr>
</table>
</body>
</html>

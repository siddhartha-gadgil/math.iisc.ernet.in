<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NMI - National Mathematics Initiative</title>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
<link href="scripts/imi.css" rel="stylesheet" type="text/css" />
<!-- Form Validation Assets Begin -->
<link rel="stylesheet" type="text/css" media="screen" href="scripts/screen.css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="lib/jquery.metadata.js" type="text/javascript"></script>
<script src="scripts/jquery.validate.js" type="text/javascript"></script>
<script src="lib/cmxforms.js" type="text/javascript"></script>
<style type="text/css">
.cmxform fieldset p.error label {
	color: red;
}
div.container {
	background-color: #eee;
	border: 1px solid red;
	margin: 5px;
	padding: 5px;
}
div.container ol li {
	list-style-type: disc;
	margin-left: 20px;
}
div.container {
	display: none
}
.container label.error {
	display: inline;
}
form.cmxform {
}
form.cmxform label.error {
	display: block;
	margin-left: 1em;
	width: auto;
}
</style>
<script type="text/javascript">
// only for demo purposes
//$.validator.setDefaults({
//	submitHandler: function() {
//		alert("submitted! (skipping validation for cancel button)");
//	}
//});

$().ready(function() {
	$("#RFP").validate({
		errorLabelContainer: $("#RFP div.error")
	});
	
	var container = $('div.container');
	// validate the form when it is submitted	
	$(".cancel").click(function() {
		validator.resetForm();
	});
	

});
</script>
<!-- Form Valiation Assets End -->
</head>
<body onload="MM_preloadImages('images/lnk-aboutimi1.jpg','images/lnk-seminars1.jpg','images/lnk-thematicprog2.jpg','images/lnk-thematicprog1.jpg','images/lnk-phdprog1.jpg','images/lnk-requestforpart1.jpg','images/lnk-visitorinfo1.jpg','images/lnk-fundingagencies1.jpg','images/lnk-contact1.jpg')">
<a name="top" id="top"></a>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;&nbsp;
      <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = '<? print date("F d, Y H:i:s", time())?>' //PHP method of getting server date
var currenttime = '<? print date("F d, Y H:i:s")?>' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime"></span>&nbsp;</td>
    <td align="right"><a href="index.php"><img src="images/icon-home.jpg" width="27" height="25" border="0" align="absmiddle" /></a>&nbsp;<a href="index.php">Home</a>&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><img src="images/spacer.gif" width="50" height="10" /></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="aboutimi-overview.php" target="_top" onclick="MM_nbGroup('down','group1','aboutimi','images/lnk-aboutimi1.jpg',1)" onmouseover="MM_nbGroup('over','aboutimi','images/lnk-aboutimi1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-aboutimi.jpg" alt="About NMI" name="aboutimi" width="108" height="31" border="0" id="aboutimi" onload="" /></a></td>
    <td><a href="atp.php" target="_top" onclick="MM_nbGroup('down','group1','thematicprogrammes','images/lnk-thematicprog1.jpg',1)" onmouseover="MM_nbGroup('over','thematicprogrammes','images/lnk-thematicprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-thematicprog.jpg" alt="Thematic Programmes" name="thematicprogrammes" width="120" height="31" border="0" id="thematicprogrammes" onload="" /></a></td>
    <td><a href="otherevents.php" target="_top" onclick="MM_nbGroup('down','group1','otherevents','images/lnk-otherevents1.jpg',1)" onmouseover="MM_nbGroup('over','otherevents','images/lnk-otherevents1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-otherevents.jpg" alt="Other Events" name="otherevents" width="107" height="31" border="0" id="otherevents" onload="" /></a></td>
    <td><a href="PhD Home.php" target="_top" onclick="MM_nbGroup('down','group1','phdprogrammes','images/lnk-phdprog1.jpg',1)" onmouseover="MM_nbGroup('over','phdprogrammes','images/lnk-phdprog1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-phdprog.jpg" alt="Ph.d Programmes" name="phdprogrammes" width="133" height="31" border="0" id="phdprogrammes" onload="" /></a></td>
    <td><a href="atp-requestforparticipation.php" target="_top" onclick="MM_nbGroup('down','group1','requestforpart','images/lnk-requestforpart1.jpg',1)" onmouseover="MM_nbGroup('over','requestforpart','images/lnk-requestforpart1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-requestforpart.jpg" alt="Request for Participation" name="requestforpart" width="110" height="31" border="0" id="requestforpart" onload="" /></a></td>
    <td><a href="visitorinfo.php" target="_top" onclick="MM_nbGroup('down','group1','visitorinfo','images/lnk-visitorinfo1.jpg',1)" onmouseover="MM_nbGroup('over','visitorinfo','images/lnk-visitorinfo1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-visitorinfo.jpg" alt="Visitor and Local Information" name="visitorinfo" width="112" height="31" border="0" id="visitorinfo" onload="" /></a></td>
    <td><a href="fundingagencies.php" target="_top" onclick="MM_nbGroup('down','group1','fundingagencies','images/lnk-fundingagencies1.jpg',1)" onmouseover="MM_nbGroup('over','fundingagencies','images/lnk-fundingagencies1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-fundingagencies.jpg" alt="Funding Agencies" name="fundingagencies" width="81" height="31" border="0" id="fundingagencies" onload="" /></a></td>
    <td><a href="contact.php" target="_top" onclick="MM_nbGroup('down','group1','contact','images/lnk-contact1.jpg',1)" onmouseover="MM_nbGroup('over','contact','images/lnk-contact1.jpg','',1)" onmouseout="MM_nbGroup('out')"><img src="images/lnk-contact.jpg" alt="Contact" name="contact" width="82" height="31" border="0" id="contact" onload="" /></a></td>
  </tr>
</table>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
  <tr>
    <td><img src="images/bannerimg-main.jpg" alt="National Mathematics Initiative (NMI)" width="880" height="190" /></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="100" height="10" /></td>
  </tr>
</table>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="402" align="left" valign="top"><!--<a href="GTO.php">--><img src="images/panel-head-currentthematicprog.jpg" alt="Current Thematic Programmes" width="402" height="29" border="0" /><!--</a>--></td>
    <td width="76" align="left" valign="top">&nbsp;</td>
    <td width="402" align="left" valign="top"><a href="PhD Home.php"><img src="images/panel-head-phdininterdisc.jpg" alt="Ph.D in Interdisciplinary Mathematical Sciences" width="402" height="29" border="0" /></a></td>
  </tr>
  <tr>
    <td width="402" align="left" valign="top"><!--<ul>
        <li><strong><a href="MLDM.php"> Machine Learning and Data Mining</a></strong><br />
          <br />
          <strong>August 2014 - July 2015 </strong><br />
        (Organized by National Mathematics Initiative) <br />
        <br />
        As   a part of its series of annual thematic programmes in mathematics and   applications, the National Mathematics Initiative (NMI) announces the   Thematic Year on &quot;Machine Learning and Data Mining&quot;</li>
    </ul> -->
	<ul>
        
<!--<li><strong><a href="GTO.php"> Game Theory and Optimization </a></strong><br />
  -->
  <li><strong><a href="CTAC.php">Complexity Theory and Cryptography</a></strong><br />
         
          <br />
          <strong>August 2016 - July 2017 </strong><br />

        (Organized by National Mathematics Initiative) <br />

        <br />

<!--       <p align="justify"> As a part of its series of annual thematic programmes in mathematics and applications, the National Mathematics Initiative (NMI) announces the Thematic Year on &quot;Game Theory and Optimization&quot;
	   </p>--></li>
    </ul></td>
    <td width="76" align="left" valign="top" background="images/panel-bak-div-vert.jpg">&nbsp;</td>
    <td width="402" align="left" valign="top"><div align="justify">The Ph.D. in Interdisciplinary Mathematical Sciences is administered by  the National Mathematics Initiative (NMI). This programme provides an  unique opportunity for students to work in areas spanning mathematics,  biology, physics and engineering. Students can work in any of the  interdisciplinary research areas mentioned below.</div>
      <br/>
      <div align="justify"><strong>Click here for: <a href = "http://admissions.iisc.ernet.in/web/ApplicationInstructions.aspx">Application Procedure </a></strong><br/>
        <br/>
        If you are intrested in this programme please select your preference department as National Mathematics Initiative (Interdisciplinary Mathematical Sciences Programme) in the online application form.<br />
        <br />
		<div align="justify">
		 <!-- <p><strong>Click here for: <a href = "http://math.iisc.ernet.in/~nmi/propos.php">Project Proposals 2014 - 2015 </a></strong></p><br />
		 <p align="justify"> The candidates shortlisted for PhD interviews under the Interdisciplinary Mathematical Sciences Programme are requested to select one or more project proposals of their interest from the list given at the
          webpage below.</p><br />

          <p align="justify">They need to indicate their project(s) of choice when they come for the interview.

          The candidates will be interviewed by the appropriate committee(s) based on their choice of project(s).	</p>  </div></td>-->
		  <p><strong><a href="Alumni.php"> IMI Alumni Students </a></strong></p>
  </tr>
  <tr>
    <td width="402" align="right" valign="top" background="images/panel-bot-grad.jpg"><a href="GTO.php"><strong>&raquo; read more</strong></a><img src="images/spacer.gif" alt="" width="10" height="25" align="absmiddle" /></td>
    <td width="76" align="left" valign="top">&nbsp;</td>
    <td width="402" align="right" valign="top" background="images/panel-bot-grad.jpg"><strong><a href="PhD Home.php"><strong>&raquo; read more</strong></a><img src="images/spacer.gif" alt="" width="10" height="25" align="absmiddle" /></strong></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="402" align="left" valign="top"><!--<a href="PTA.php">--><img src="images/panel-head-upcomingthematicprog.jpg" alt="Upcoming Thematic Programmes" width="402" height="29" border="0" /></a></td>
    <td width="76" align="left" valign="top">&nbsp;</td>
    <td width="402" align="left" valign="top"><img src="images/panel-head-otherevents.jpg" alt="Other Events" width="402" height="29" border="0" /></td>
  </tr>
  <tr>
    <td width="402" align="left" valign="top"><div align="justify">
      <ul>
        <!--<li><strong>Machine Learning and Data Mining<br />
          (August 2014 - July 2015)</strong> <br />
          <br />
        </li>-->
       <!-- <li><strong>Game Theory and Optimization<br />
          (August 2015 - July 2016)</strong> <br />
          <br />-->
        </li>
 <!--       <li><strong><a href="CTAC.php">Complexity Theory and Cryptography</a><br /><br />
(August 2016- July 2017)</strong>  <br />
 -->         <br />
        </li>
      </ul>
    (Organized by NMI)

</div></td>
    <td width="76" align="left" valign="top" background="images/panel-bak-div-vert.jpg">&nbsp;</td>
    <td width="402" align="left" valign="top"><ul>
   <!--   <li>
        <p><a href="http://math.iisc.ernet.in/~vimss/workshop.php">Statistical Methods for Bioinformatics</a>
        </p>
      </li>
     <li><p>
   <b> <a href="http://www.csa.iisc.ernet.in/sem-evts/hdna.html">Workshop on High Dimensional Network Analytics</a></b>
<br><br>
Organized by:<br>
National Mathematics Initiative, IISc<br>
Department of Computer Science and Automation, IISc<br>
IBM India Research Labs<br><br>

Venue:                 Choksi Hall, IISc Campus<br>
Dates:                 December 16-19, 2013 <br>

For more details visit:<br>
<a href="http://www.csa.iisc.ernet.in/sem-evts/hdna.html">http://www.csa.iisc.ernet.in/sem-evts/hdna.html</a>

</p></li>-->
 <p><strong> The Seventh International Workshop on Signal Design and Its Applications in Communications (IWSDA'15)</strong>
<br /><br />
Organized by:<br><br />
National Mathematics Initiative, IISc<br>
(under Technical Co-Sponsorship by the IEEE Communication Society, Bangalore Chapter)<br><br />


Venue:                 GJH, ECE, IISc Campus<br>
Dates:                 September 13 - 17, 2015<br><br />

For more details visit:<br>
<a href=" http://sist.swjtu.edu.cn/imc/iwsda15/"> http://sist.swjtu.edu.cn/imc/iwsda15/</a>

</p>

<!--      <li>
  <p>    <a href="otherevents-seminar-nul.php">Seminar by Prof. Saman Halgamuge, University of Melbourne</a></p>
      </li>-->
    </ul></td>
  </tr>
  <tr>
    <td width="402" align="right" valign="top" background="images/panel-bot-grad.jpg"><!--<a href="atp.php">--><a href="CTAC.php"><strong>&raquo; read more</strong></a><img src="images/spacer.gif" alt="" width="10" height="25" align="absmiddle" /></td>
    <td width="76" align="left" valign="top">&nbsp;</td>
    <td width="402" align="right" valign="top" background="images/panel-bot-grad.jpg"><strong><a href="otherevents.php"><strong>&raquo; read more</strong></a><img src="images/spacer.gif" alt="" width="10" height="25" align="absmiddle" /></strong></td>
  </tr>
</table>
<p>&nbsp;</p>
<tr>
  <td width="402" align="left" valign="top"><br />
    <table width="880" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="616" align="left" valign="top" background="images/panel-bak-div-horz.jpg"><img src="images/spacer.gif" width="10" height="25" align="absmiddle" /><a href="index.php">Home</a> | <a href="contact.php">Contact</a> | <a href="http://www.iisc.ernet.in" target="_blank">About IISc</a></td>
        <td width="264" align="right" valign="top" background="images/panel-bak-div-horz.jpg"><span class="smalltxt">Site Design: </span><a href="http://www.surfzone-india.com" target="_blank"><span class="smalltxt">SurfZone Technologies</span></a>&nbsp;</td>
      </tr>
    </table>
</body>
</html>

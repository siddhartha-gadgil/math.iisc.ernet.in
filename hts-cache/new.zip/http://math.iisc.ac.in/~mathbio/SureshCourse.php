﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="courses.php">
      <div class="leftmenucell">Courses</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>COURSE 2010 </strong></h1>
          <ul>
            <div align="center"><strong>“High-Performance Scientific Computing on the GPU with emphasis on CAD and FEA”</strong><br />
                <br />
              by<br />
              <br />
              
              <strong>Prof. K. Suresh</strong><br /> 
              University of Wisconsin, Madison, USA<br /><br />
              <strong>ABSTRACT              </strong><br /></div><br />
              <div align="justify">The objective of this short-course is to explore the use of graphics
                programmable units (GPUs) for accelerating scientific computations.
                Specifically, we shall consider state-of-the-art CUDA-enabled NVidia
                GPUs to address some of computational challenges associated with
                geometric modeling and finite element analysis. The short-course
                consists of the following five lectures (additional lectures will be
                delivered, if necessary):
                <br /> 
                <br /> 
              </div>
              <li> Introduction of GPU: <strong>Monday,  February 01, 2010 at 3:30 pm</strong></li>
              
              <br /> 
              <li> CUDA programming: <strong>Monday,  February 08, 2010 at 3:30 pm</strong></li>
              
              <br /> 
              <li> CUBLAS and FFT on the GPU: <strong>Monday,  February 15, 2010 at 3:30 pm</strong></li>
              
            
            <No lecture on 22^nd February 2010>

<br /> 
              <li> Geometric computations using CUDA:  <strong>Monday, March 01, 2010 at 3:30 pm </strong></li>

<br /> 
              <li> Finite element analysis using CUDA:  <strong>Monday, </strong><strong>March 08, 2010 at 3:30 pm </strong></li>

<br /> 
              <li> Biomechanics applications on the GPU:  <strong>Monday, </strong><strong>March 15, 2010, 3:30 pm </strong></li><br /><br />

This is a hands-on course where the students are encouraged to ‘play
around’ with GPU programming; familiarity with Matlab and C
programming is the only pre-requisite.


              
                <!--
            <li>            “The exploration of excitability in pancreatic beta-cells: some recent developments” <br />
              - May 22, 2008 
              (Pranay Goel, National Institutes of Health, Bethesda) <br />
              <br />
            </li>
            <li>              “Virtual screening - target and ligand-based approaches to identify activemolecules”<br />
              - August 06, 2008 
              (Dr. Andreas Bender, Universiteit Leiden, Netherlands)<br />
              <br />
            </li>
            <li>            “Cheminformatics - an introduction to analyzing and handling chemical data” <br />
              -  August 07, 2008(Dr. Andreas Bender, Universiteit Leiden, Netherlands)<br />
              <br />
            </li>
            <li>              “Computational tools in drug discovery - how computers and algorithms can support the discovery of new drugs” <br />
              - August 08, 2008 (Dr. Andreas Bender, Universiteit Leiden, Netherlands)<br />
              <br />
            </li>
            <li>            “Estimation of function thresholds using multistage adaptive procedures” <br />
              - August 12, 2008 (Dr. Moulinath Banerjee, University of Michigan,USA)<br />
              <br />
            </li>
            <li>            “Pharmaceutical applications of molecular modelling other than drug discovery” <br />
              - October 20, 2008 (Alex Bunker, University of Helsinki, Finland)<br />
              <br />
            </li>
            <li>            “Mechanical properties of cells and tissues” <br />
              - November 05, 2008              (Jean-Francois Joanny, Institut Curie, Paris)<br />
              <br />
            </li>
            <li>              “Temporal spike pattern learning in biological systems” <br />
              - November 14, 2008 (Dr. Sachin S. Talathi, University of Florida, Gainesville, USA)<br />
              <br />
            </li>
            <li> “Neuroeconomic Correlates of regret and rejoice functions: A functiona MRI Investigation” <br />
              - November 26, 2008 (Dr. Chandrasekhar Pammi, Max-Planck Institute for Biological Cybernetics, Tuebingen, Germany)<br />
              <br />
            </li>
            <li>“Assessing copy number variation using genome-wide alignments” <br />
              - March 02, 2009 (Dr. Deepayan Sarkar, Fred Hutchinson Cancer Research Institute USA)<br />
              <br />
            </li>
            <li>            “Modelling large Spatial Datasets using Gaussian Process models:Applications in Environmental Sciences” <br />
              - March 26, 2009              (Dr. Sudipto Banerjee Division of Biostatistics, University of Minnesota, USA)<br />
              <br />
            </li>
            <li>              “Systems Biology Approaches for the Environmental Biotechnology Applications” <br />
              - May 06, 2009 (Prof. Radhakrishnan Mahadevan
,                  Department of Chemical Engineering and Applied Chemistry,                University of Toronto)
			  <br />
 <br />
            </li>
			<li>              “Modeling eye movements in a shape recognition task”
<br />
              - July 15, 2009 (Dr. Preeti Verghese, The Smith-Kettlewell Eye Research Institute, San Francisco, CA)<br />
            </li>
			<br />
			<li>             "Stochastic modelling in Immunology"
<br />
              - August 06, 2009 ( Prof. Carmen Molina-París and Prof. Grant Lythe, Department of Applied Mathematics, School of Mathematics,                 University of Leeds)<br />
            </li>
			<br />
			<li>              "Robustness and evolution of novel phenotypes in a complex signalling circuit"

<br />
              - August 10, 2009 (Dr. Karthik Raman, University of Zurich)<br />
            </li>
			<br />
			<li>              "Effect of Molecular Crowding on stretching of bio-polymers"
 <br />
              - September 30, 2009 (Prof. Sanjay Kumar, Professor of Physics, Banaras Hindu University, Varanasi)<br />
            </li>
				<br />
				
			<li>              "Investigating protein structural mechanisms : A systems biology approach" <br />
              - December 15, 2009 (Dr. Natarajan Kannan, University of Georgia, Athens)<br />
            </li>-->
                <br />
            </ul>
          <pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

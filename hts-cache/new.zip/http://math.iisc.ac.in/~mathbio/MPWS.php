﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="249" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="MPWSOrgCom.php">
      <div class="leftmenucell">Organizing Committee</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="MPWSResourcePersons.php">
      <div class="leftmenucell">Resource Persons</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="MPWSVenue.php">
      <div class="leftmenucell">Venue</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Workshops.php">
      <div class="leftmenucell">Workshop and Conference</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <td> <a href="http://math.iisc.ernet.in/%7Eimi/math-biorequestforparticipation.php">
      <div class="leftmenucell">
        Request for Participation

</div>
    </a></td>
  </tr>
  <tr>
    <td height="10"><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  
 <tr>
    <td><a class="left" href="MPWSdeadlines.php">
      <div class="leftmenucell">Deadline</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td> <a class="left" href="http://www.math.iisc.ernet.in/~mathbio/downloads/MPWS_PS.pdf">
      <div class="leftmenucell">Programme Schedule</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>

</table></p></td>
        <td class="maintext" width="731" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>Workshop and Symposium on Mathematical Physiology  <br/><br />
January 15 - 23, 2011 </strong></h1>

			<br />
			
			
           <p align="justify">
       
        Physiology is one of the oldest branches of biology to have attracted systematic
          theories of structure and function. The Nobel prize winning study of nerve impulse
          propagation by Hodgkin and Huxley, or physical basis of the regulation of insulin
          secretion by beta cells, are just two examples of their importance and
          applicability. Modern investigation in the field relies heavily on mathematics to
          complement our understanding. The twin goals of this meeting are to encourage and
          enhance pedagogy and research in mathematical aspects of physiology among students
          and researchers.    <br/>
          <br/>
          The conference comprises of two components: a week-long tutorial Workshop and a
          two-day Symposium.  <br/>
          <br/>
          The Workshop, January 15 - 21, 2011 is designed to increase awareness about mathematical
          modeling in physiology. Participants will attend an intensive series of lectures as
          well as hands-on sessions on various topics in Physiology, which will introduce them
          to classical as well as the state-of-the art in modeling. The tutorials on are aimed
          largely at MSc level students, however many others are likely to find them
          attractive as well.  <br/>
          <br/>
          Participants will be resident at accommodation arranged near IISER Pune for the
          duration of the Workshop. <br/>
          <br/>
          The workshop will be immediately followed by two days of
          research talks:  <br/>
          <br/>
          The Symposium, January 22 - 23, 2011 hopes to bring together theoreticians and experimentalists
          who work on - or would like to foray into - theoretical and mathematical approaches
          to physiology. <br/>
          <br/> 
          Topics of interest at the Workshop and Symposia include: cell signaling, metabolism,
          neuroscience, cardiac dynamics, chronobiology, insulin secretion and control and
          many others.   
           
<BR> 
<BR>Click here for: <a href="http://www.math.iisc.ernet.in/~mathbio/downloads/MPWS_Selected_Participants.pdf"> Selected Participants List</a>
			  
          </ul>
<pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

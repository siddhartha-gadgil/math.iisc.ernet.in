﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Convener.php">
      <div class="leftmenucell">Convener</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="PhD Participating Faculty.php">
      <div class="leftmenucell">Participating Faculty</div>
    </a></td>
    
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="Intvwprocess.php">
      <div class="leftmenucell">Interview Process</div>
    </a></td>
    
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Students.php">
      <div class="leftmenucell">Students under Interdisciplinary Mathematical Sciences Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><a class="left" href="propos.php">
      <div class="leftmenucell">Project Proposals</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table>
</p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <center><h2><strong>Project Proposals</strong></h2></center>
		  <ul>
		<!--  <li><a href="profil.php">Profiling the cancer stem cell phospho-proteome for understanding self-renewal and cellular transformation useful for cancer treatment</a></li><br>
		  <li><a href="robust.php">Robustness and stability of ecological systems</a></li><br>
		 <!-- <li><a href="nmr.php">Advanced Optimization Models and Algorithms for NMR Structure Calculation</a></li><br />-->
		<!--  <li><a href="visual.php">Visual Neuroscience: From Neurons to Perception</a></li><br />-->
		  <!--<li><a href="EEG.php">Development of EEG Source Localization Techniques</a></li><br />-->
		  <!--<li><a href="metabolism.php">Large multi-molecular machines in cellular metabolism and signalling: network analysis, dynamics, energetics and 3-D reconstruction</a></li><br />-->
<!--
		  <li><a href="gene.php">Modeling gene regulatory networks (GRNs) during flower development: data driven integrative modeling of dynamic molecular networks during rice flower development</a></li><br />
		  <li><a href="metabolome.php">Exploring the stem cell metabolome using NMR profiling for understanding self-renewal and discover potential biomarkers useful for cancer treatment</a></li><br />
		  <li><a href="cogni.php">Unraveling neural computations underlying cognition</a></li><br />
		  <li><a href="HIV.php">Rational Design of Drugs for HIV Infection</a></li><br />
		  <li><a href="molecule.php">Analysis of high-density single molecule localization and trajectories from live cells</a></li><br />
		 
		<li><a href="3D structures.php">Relationship between flexibility and dynamics of three-dimensional structures of biomolecular complexes and the functional sites</a></li><br />
		
  <li><a href="flows.php">Modelling 'flows' in biological networks and their implications in understanding variations in disease</a></li> <br />
		-->  
		   <li><a href="artificial_neural.php">Developing an artificial neural network model for motor control</a></li><br />
		  
		  <li><a href="brain_function.php">Mathematical modeling of brain function</a></li><br />
		 
		 <!-- <li><a href="NMR_Mass.php">NMR and Mass Spectrometry based integrated methods to probe metabolic processes in cancer cells</a></li><br />
		  -->
 		  <li><a href="Mapping_space.php">Mapping space in the brain</a></li><br />

		 <!--   <li><a href="Multi-Scale.php">Multi-Scale modelling of stem cell differentiation behaviour in the presence of electric field</a></li><br />
-->
		  <li><a href="protein.php">Understanding protein folding and unfolding landscape</a></li><br />

		  <li><a href="bio_func.php">Towards understanding the role of molecular diffusion in biological function</a></li><br />

		 <li><a href="Net_bio.php">Network biology: Biomolecular structures, interactions, dynamics and implications in biological and metabolic pathways</a></li><br />

 



 </ul>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <!--<p align="leftjustify">&nbsp;</p>-->
          <br />
         <!-- <p align="justify">&nbsp;</p>-->
          <p><span class="gotopcontainer"><br />
          </span></p></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

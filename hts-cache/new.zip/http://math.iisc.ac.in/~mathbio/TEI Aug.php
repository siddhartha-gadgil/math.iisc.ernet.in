﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="TEI OrgCom.php">
      <div class="leftmenucell">Organizing Committee</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="TEIResourcePersons.php">
      <div class="leftmenucell">Resource Persons</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="TEIVenue.php">
      <div class="leftmenucell">Venue</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <td><a class="left" href="rfp.php"><div class="leftmenucell">Request for Participation</div></a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  
  <td> <a href="TEI deadlines.php">
      <div class="leftmenucell">
       Deadline

</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong> International meeting on

“Theoretical and Experimental Immunology”<br /> <br/> 
		  August 16, 2011<br />
 </strong></h1>
		  <div align="justify">
		    <p><br />
		      Immunology is the study of the host defence network against infections,
		      tumors, allergies etc. Experimental immunology is well studied and has
		      shed light on the inner workings of immune cells. Studies in this field
		      have led to a better understanding of the host defense network. On the
		      other hand, theoretical immunology, utilizing mathematical tools, is a
		      relatively newer area of study. Theoretical immunology involves the
		      development of mathematical and computational models of biological
		      phenomena that unravel, in synergy with experiments, new insights into the
		      workings of our immune system.<br />
  <br />
		      
		      How does our immune system distinguish between what belongs to us and what
		      is external?  Why are some diseases cured and others not?  How does our
		      immune system respond to the evolution of pathogens such as HIV?  This
		      meeting will bring in top notch researchers in the field of theoretical
		      and experimental immunology. The talks are expected to be pedagogic in
		      nature with the first half as an overview of the field and the second half
		      on the speaker’s research contributions. This meeting will seek answers to
		      questions, which are at the heart of our understanding of Immunology and
		      may pave the way for the design of potent immunogens and vaccines.
  <br />
  <br />
		      
		      We are happy that this unique meeting will be held in the Indian Institute
		      of Science, Bangalore which is the Mecca of scientific research and
		      teaching in India and celebrated hundred years of its existence in 2009.
  <br />
  <br />
		      
		      Finally, we welcome you to this event and look forward to your active
		      participation in making this meeting a resounding success!<br />
  <br /><br/>
  
  <marquee width="100%" scrolldelay="100" direction="left"
                         style="border-style: dotted; border-width: 0px;"
                         onmouseover="this.stop()" onmouseout="this.start()"
                                                 behaviour="scroll"> <a href="http://www.math.iisc.ernet.in/~mathbio/downloads/Program and instructions.pdf.pdf"><strong>
                        Click here for the Programme Schedule and  General Instructions</strong></a> </marquee>
						             </div>
          </ul>          <p>&nbsp;</p>
		  
         
		      
  <strong>REGISTRATION INFORMATION:</strong><br/>
  <br/>
		      
		      Interested students, postdoctoral fellow and research fellows are required
		      to submit an application to attend the meeting via the web
		      (<a href = "http://www.math.iisc.ernet.in/~mathbio/rfp.php">http://www.math.iisc.ernet.in/~mathbio/rfp.php)</a> by July 20,
		      2011. Please ensure that name, address, email, mobile number, date of
		      birth, educational qualifications, present affiliation and a short write
		      up (250-300 words) on the reason to attend this meeting is accurately
		      submitted. <br/>
		      <br/>
			  
			  Selected participants will be informed by July 15, 2011. Please
		      note that there are no registrations fees for this meeting. <strong>However,
		      participants will need to make their own arrangements for their stay (click here for <a href= "http://www.math.iisc.ernet.in/~mathbio/downloads/HOTELS.pdf">List of Hotels.)</a></strong> All
		      participants will receive registration materials and coupons for lunch and
		      high tea on August 16, 2011.<br/>
  <br/>
		      <strong></p>
		    <p>For any further information, please contact Theoretical and Experimental
		      Immunology Meeting, IISc Mathematics Initiative, Dept. of Mathematics,
		      IISc, Bangalore-560012.</p>
		    <p>Web:<a href= "http://www.math.iisc.ernet.in/~mathbio/TEI Aug.php">http://www.math.iisc.ernet.in/~mathbio/TEI Aug.php</a><br/>
		      Email: <a href="mailto:imi@math.iisc.ernet.in">imi@math.iisc.ernet.in </a><BR><br />
			  Click here for: <a href= "http://www.math.iisc.ernet.in/~mathbio/downloads/List of Participants.pdf.pdf">Selected Participants List</a>
		      
		      </ul>
		      </h1>
		      </p>
		    </div>
			 <div align="center"><strong><a href="http://math.iisc.ernet.in/~mathbio/MiniSymp.php" align="justify"></div>
			 <pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  
  <tr>
    <td><a class="left" href="QGGAWSOrgCom.php">
      <div class="leftmenucell">Organizing Committee</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="QGGAWSResourcePersons.php">
      <div class="leftmenucell">Resource Persons</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="QGGAWSVenue.php">
      <div class="leftmenucell">Venue</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Workshops.php">
      <div class="leftmenucell">Workshop and Conference</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <td> <a href="http://math.iisc.ernet.in/%7Eimi/math-biorequestforparticipation.php">
      <div class="leftmenucell">
        Request for Participation

</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>One Day Workshop on Topics in Quantitative Genetics & Genome Analysis <br/><br/>
(August 28, 2010) </strong></h1>
          <div align="justify">
            <br />
            Mathematics has been used in Genetics since antiquity, and many sophisticated techniques of probability theory are used to predict the response to selection given data on the phenotype and relationships of individuals in biology. Theoretical Computer Science has contributed by developing novel algorithms and methods to analyze data from population genetic and genome scale analysis to find variations, patterns of nucleotide distributions, and classification based on multiple variables. Such theoretical analysis are used increasingly in many areas in Biology from Epidemiology to Bioinformatics.</div>
          <div align="justify"><br />
              <br />
            Researchers in Biological Sciences now routinely use software based on these methods to analyze their genetic and genomic data. Unfortunately many are not aware of the underlying concepts, model assumptions, and limits of applicability of these methods/techniques. Exposure to these is of great importance, and it will certainly enhance the quality of research and this area and make the researchers better equipped to deal with genetic and genomic data.          </div>
          <div align="justify"><br />
              <br />
            Keeping the above in mind, we plan to organize a one-day Workshop, where a few important topics in quantitative genetics and genome analysis will be taught by eminent and active theoretical researchers in those fields. We take advantage of the International Congress of Mathematics to be held in Hyderabad during August to invite speakers working in similar lines.          </div><br /><br />
		  <strong> Topics to be covered are: </strong><br /><br />
		  
          <ul>
            <li>Mutation-Selection Balance, Classification; Phylogenetic Reconstruction </li>
            <li>Statistical Analysis of DNA Sequences Based on Distributions of DNA words; and, the problem of Identification of Genomic Islands in Microbial Genomes </li>
            <li>Genome Wide Association Studies: Introduction, Prospects, Pitfalls and Projections </li>
          </ul>
          <blockquote>
            <pre>&nbsp;</pre>
          </blockquote></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

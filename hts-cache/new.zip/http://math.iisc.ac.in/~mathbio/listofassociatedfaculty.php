﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p align="center">
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
   <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="courses.php">
      <div class="leftmenucell">Courses</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Workshops.php">
      <div class="leftmenucell">Wokshop and Conference</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Alumni.php">
      <div class="leftmenucell">IMI Alumni Students</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>LIST OF ASSOCIATED FACULTY</strong></h1>
          <p>&nbsp;</p>
          <div align="center"><br />
            <table width="680" border="0" cellspacing="0" cellpadding="5">
              <tr>
                <td width="9" align="left" valign="top">&bull;</td>
                <td width="228" align="left" valign="top"><strong><a href="http://mrc.iisc.ernet.in/Faculty/Regular/Bikram/Bikram_Profile.htm" target="_blank">Bikramjit Basu</a></strong><br />
                  Associate Professor <br />
                  Department of Materials Research Centre <br />
                  Indian Institute of  Science <br />
                  Bangalore  - 560012</td>
                <td width="300" align="left" valign="top">Phone : +91-80-2293 3256/ 09482570341<br />
                  E-mail: <a href="mailto:bikram@mrc.iisc.ernet.in">bikram@mrc.iisc.ernet.in</a><br />
                  </td>
                <td width="103" align="left" valign="top"><!--<img src="images/faculty-chiranjib.jpg" alt="Prof. Chiranjib Bhattacharya" width="125" height="125" class="imglink" />--></td>
              </tr>
            </table>
            <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
            <br />
            <table width="680" border="0" cellspacing="0" cellpadding="5">
              <tr>
                <td width="7" align="left" valign="top">&bull;</td>
                <td width="211" align="left" valign="top"><strong><a href="http://proline.physics.iisc.ernet.in/home/Main_Page" target="_blank">Nagasuma Chandra</a></strong><br />
                  Professor<br />
                  Department of Biochemistry<br />
                  Indian Institute of Science<br />
                  Bangalore - 560 012</td>
                <td width="289" align="left" valign="top">Phone: 91-80-2293-2892, <br />
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                91-80-2369-1409 (Extn #24)<br />
                  E-mail: <a href="mailto:nchandra@physics.iisc.ernet.in">nchandra@biochem.iisc.ernet.in</a><br /></td>
                <td width="133" align="left" valign="top"><img src="images/faculty-nagasuma.jpg" alt="Nagasuma Chandra" width="125" height="125" class="imglink" /></td>
              </tr>
            </table>
            <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
            <div class="gotopcontainer"><br />
            </div>
            <br />
            <table width="680" border="0" cellspacing="0" cellpadding="5">
              <tr>
                <td width="7" align="left" valign="top">&bull;</td>
                <td width="206" align="left" valign="top"><strong><a href="http://chemeng.iisc.ernet.in/webpage/narendra.html" target="_blank">Narendra M Dixit</a></strong><br />
                  Associate Professor<br />
                  Department of Chemical Engineering<br />
                  Indian Institute of Science<br />
                  Bangalore-  560012</td>
                <td width="294" align="left" valign="top">Phone: 91-80-2293-2768<br />
                  E-mail: <a href="mailto:narendra@chemeng.iisc.ernet.in">narendra@chemeng.iisc.ernet.in</a><br /></td>
                <td width="133" align="left" valign="top"><img src="images/faculty-narendra.jpg" alt="Narendra Dixit" width="125" height="125" class="imglink" /></td>
              </tr>
            </table>
            <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
            <br />
            <table width="680" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="8" align="left" valign="top">&bull;</td>
              <td width="222" align="left" valign="top"><strong><a href="http://vishuguttal.wordpress.com/" target="_blank">Vishwesha Guttal</a></strong><br />
Associate Professor<br />
Centre for Ecological Sciences<br />
Indian Institute of Science<br />
Bangalore - 560012</td>
              <td width="277" align="left" valign="top">Phone: +91-80-2360-5797; +91-80-2293-2872<br />
E-mail : <a href="mailto:guttal@ces.iisc.ernet.in">guttal@ces.iisc.ernet.in</a><br />
<!--<a href="http://math.iisc.ernet.in/%7Egadgil/" target="_blank"></a>--></td>
              <td width="133" align="left" valign="top"><!--<img src="images/faculty-siddhartha.jpg" alt="Prof. Siddhartha Gadgil" width="125" height="130" class="imglink" />--></td>
            </tr>
          </table>
          <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="220" align="left" valign="top"><strong><a href="http://math.iisc.ernet.in/~skiyer/" target="_blank">Srikanth Iyer</a></strong><br />
      Professor<br />
      Department of Mathematics<br />
      Indian Institute of Science <br />
      Bangalore- 560012</td>
    <td width="278" align="left" valign="top">Phone: 080-22933327<br />
      Email: <a href="mailto:skiyer@math.iisc.ernet.in">skiyer@math.iisc.ernet.in</a><br /></td>
    <td width="133" align="left" valign="top"><!--<img src="images/faculty-veni.jpg" alt="Veni Madhavan" width="125" height="112" class="imglink" />--></td>
  </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="225" align="left" valign="top"><strong><a href="http://www.physics.iisc.ernet.in/~maiti/" target="_blank">Prabal K Maiti</a></strong><br />
      Assistant Professor<br />
      Department of  Physics<br />
      Indian Institute of  Science<br />
      Bangalore-560012 </td>
    <td width="273" align="left" valign="top">Phone: 91-080- 2293  2865, 2360 7301<br />
      E-mail: <a href="mailto:maiti@physics.iisc.ernet.in">maiti@physics.iisc.ernet.in</a><br />
      <a href="http://www.physics.iisc.ernet.in/~maiti/"></a></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-prabal.jpg" alt="Prabal K Maiti" width="125" height="125" class="imglink" /></td>
  </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<div class="gotopcontainer"><br />
  <div class="gotop"><a href="#top">Go Top</a></div>
  <br />
  <br />
</div>
<br />
<br />
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="227" align="left" valign="top"><strong><a href="http://math.iisc.ernet.in/~nands/" target="_blank">A. K. Nandakumaran</a></strong><br />
      Professor<br />
      Department of Mathematics<br />
      Indian Institute of Science<br />
      Bangalore – 560012</td>
    <td width="271" align="left" valign="top">Phone: 91-80-2293 2835<br />
      E-mail: <a href="mailto:nands@math.iisc.ernet.in">nands@math.iisc.ernet.in</a><br />
      <a href="http://math.iisc.ernet.in/%7Enands/" target="_blank"></a></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-nandakumaran.jpg" alt="Prof. A. K. Nandakumaran" width="125" height="125" class="imglink" /></td>
    </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="224" align="left" valign="top"><strong><a href="http://drona.csa.iisc.ernet.in/~vijayn/" target="_blank">Vijay Natarajan</a></strong><br />
      Associate  Professor<br />
      Department of Computer Science and Automation<br />
      Super Computer Education and Research Centre<br />
      Indian  Institute of Science <br />
      Bangalore-  560012</td>
    <td width="274" align="left" valign="top">Phone:  91- 80- 22932909<br />
      E-mail: <a href="mailto:vijayn@csa.iisc.ernet.in">vijayn@csa.iisc.ernet.in</a><br /></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-vijay.jpg" alt="Vijay Natarajan" width="125" height="127" class="imglink" /></td>
  </tr>
</table>


<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
            <br />
            <table width="680" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="8" align="left" valign="top">&bull;</td>
              <td width="222" align="left" valign="top"><strong><a href="http://mcbl.iisc.ernet.in/Welcome%20to%20MCBL/Faculty/Nath/Nath.htm" target="_blank">Utpal Nath</a></strong><br />
Assistant Professor<br />
Department of Microbiology & Cell Biology<br />
Indian Institute of Science<br />
Bangalore - 560012</td>
              <td width="277" align="left" valign="top">Phone: +91 80 22932414<br />
E-mail : <a href="mailto:utpal@mcbl.iisc.ernet.in">utpal@mcbl.iisc.ernet.in</a><br />
<!--<a href="http://math.iisc.ernet.in/%7Egadgil/" target="_blank"></a>--></td>
              <td width="133" align="left" valign="top"><!--<img src="images/faculty-siddhartha.jpg" alt="Prof. Siddhartha Gadgil" width="125" height="130" class="imglink" />--></td>
            </tr>
          </table>



<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="225" align="left" valign="top"><strong><a href="http://www.serc.iisc.ernet.in/~dpal/" target="_blank">Debnath Pal</a></strong><br />
      Associate Professor<br />
      Department of Supercomputer Education and Research Centre<br />
      Indian Institute of  Science<br />
      Bangalore- 560 012</td>
    <td width="273" align="left" valign="top">Phone: +91-80-2293-2901,  2360-0654 &nbsp;&nbsp;<br />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                extn: 306 <br />
      E-mail: <a href="mailto:dpal@serc.iisc.ernet.in">dpal@serc.iisc.ernet.in</a><br /></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-debnath.jpg" alt="Debnath Pal" width="125" height="153" class="imglink" /></td>
  </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="222" align="left" valign="top"><strong> <a href="http://www.physics.iisc.ernet.in/~rahul/" target="_blank">Rahul Pandit</a></strong><br />
      Professor<br />
      Centre for Condensed Matter Theory<br />
      Department of Physics<br />
      Indian Institute of Science<br />
      Bangalore, 560 012</td>
    <td width="276" align="left" valign="top">Phone: +91 80 2293  2249,  2293 2863 <br />
      E-mail: <a href="mailto:rahul@physics.iisc.ernet.in">rahul@physics.iisc.ernet.in</a> <br /></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-rahul.jpg" alt="Rahul Pandit" width="125" height="125" class="imglink" /></td>
  </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="225" align="left" valign="top"><strong><a href="http://www.serc.iisc.ernet.in/~raha/" target="_blank">Sowmyendu Raha</a></strong><br />
      Associate Professor <br />
      Department of    Supercomputer Education and Research Centre <br />
      Indian Institute of Science<br />
      Bangalore-    560012</td>
    <td width="273" align="left" valign="top">Phone: +91-80-2293-2791<br />
	+91-80-2360-0654 extn :316 <br />
      <!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
	  E-mail: <a href="mailto:raha@serc.iisc.ernet.in">raha@serc.iisc.ernet.in</a> <br /></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-sowmyendu.jpg" alt="Sowmyendu Raha" width="125" height="125" class="imglink" /></td>
  </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="8" align="left" valign="top">&bull;</td>
    <td width="212" align="left" valign="top"><strong><a href="http://www.physics.iisc.ernet.in/~rajan/" target="_blank">K. Rajan </a></strong><br />
      Professor<br />
      Department of Physics<br />
      Indian Institue of Science<br />
      Bangalore-560 012</td>
    <td width="287" align="left" valign="top">Phone:     91 - 80 - 2933280 <br />
      E-mail: <a href="mailto:rajan@physics.iisc.ernet.in">rajan@physics.iisc.ernet.in</a> <br /></td>
    <td width="133" align="left" valign="top"><!--<img src="images/faculty-sriram.jpg" alt="Sriram Ramaswamy" width="125" height="125" class="imglink" />--></td>
  </tr>
</table>
<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<div class="gotopcontainer"><br />
  <div class="gotop"><a href="#top">Go Top</a></div>
  <br />
  <br />
</div>
<br />
<br />
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="225" align="left" valign="top"><strong><a href="http://math.iisc.ernet.in/~rangaraj" target="_blank">Govindan Rangarajan</a></strong> (Coordinator)<br />
      Professor<br />
      Department of Mathematics<br />
      Indian Institute of Science<br />
      Bangalore - 560012</td>
    <td width="273" align="left" valign="top">Phone : 91-80-22933213, 22932264<br />
      E-mail : <a href="mailto:rangaraj@math.iisc.ernet.in">rangaraj@math.iisc.ernet.in</a><br />
      <a href="http://math.iisc.ernet.in/%7Erangaraj" target="_blank"></a></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-rangaraj.jpg" alt="Prof. Govindan Rangarajan" width="125" height="125" class="imglink" /></td>
    </tr>
</table>
          <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
          <br />
          <table width="680" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="9" align="left" valign="top">&bull;</td>
              <td width="227" align="left" valign="top"><strong><a href="http://mbu.iisc.ernet.in/~sks/" target="_blank">Sujit Kumar Sikdar</a></strong><br />
                Professor<br />
                Department of Molecular Biophysics Unit <br />
                Indian Institute of Science <br />
                Bangalore-560012</td>
              <td width="271" align="left" valign="top">Phone: 91-80-2293 2844, 91-80-2293 3220<br />
                E-mail: <a href="mailto:sks@mbu.iisc.ernet.in">sks@mbu.iisc.ernet.in</a> <br /></td>
              <td width="133" align="left" valign="top"><img src="images/faculty-sujit.jpg" alt="Sujit Kumar Sikdar" width="125" height="125" class="imglink" /></td>
              </tr>
          </table>
          <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
          <br />
          <table width="680" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="10" align="left" valign="top">&bull;</td>
              <td width="250" align="left" valign="top"><strong><a href="http://pauling.mbu.iisc.ernet.in" target="_blank"> N.  Srinivasan </a></strong><br />
                Professor<br />
                Department of Molecular Biophysics  Unit <br />
                Indian Institute of Science <br />
                Bangalore- 560 012</td>
              <td width="200" align="left" valign="top">Phone: 91-80-22932837<br />
                E-mail: <a href="mailto:ns@mbu.iisc.ernet.in">ns@mbu.iisc.ernet.in</a><br /></td>
              <td width="220" align="left" valign="top">&nbsp;</td>
            </tr>
          </table>
          <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
          <br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="9" align="left" valign="top">&bull;</td>
              <td width="221" align="left" valign="top"><strong><a href="http://www.mecheng.iisc.ernet.in/~suresh/" target="_blank">G. K. Anantha Suresh</a></strong><br />
Professor<br />
Mechanical Engineering  <br />
Indian Institute of Science<br />
Bangalore -  560012</td>
              <td width="285" align="left" valign="top">Phone: 91-80-2293 2334<br />
E-mail: <a href="mailto:suresh@mecheng.iisc.ernet.in">suresh@mecheng.iisc.ernet.in</a><br /></td>
              <td width="125" align="left" valign="top"><img src="images/faculty-anantha.jpg" alt="Prof. G. K. Anantha Suresh" width="125" height="143" class="imglink" /></td>
            </tr>
          </table>
          <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<table width="680" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="9" align="left" valign="top">&bull;</td>
    <td width="226" align="left" valign="top"><strong><a href="http://isu.iisc.ernet.in/~vasu/" target="_blank">R. M. Vasu</a></strong><br />
      Professor<br />
      Department of Instrumentation<br />
      Indian Institute of Science<br />
      Bangalore - 560 012</td>
    <td width="272" align="left" valign="top">Phone:  91-80-22932889 / 22933191<br />
      E-mail: <a href="mailto:chairman@isu.iisc.ernet.in">chairman@isu.iisc.ernet.in</a><br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:vasu@isu.iisc.ernet.in">vasu@isu.iisc.ernet.in</a><br /></td>
    <td width="133" align="left" valign="top"><img src="images/faculty-vasu.jpg" alt="R. M. Vasu" width="125" height="125" class="imglink" /></td>
    </tr>
</table>
          <!--<div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /><br />
          </div>
          <br />
          <table width="680" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="9" align="left" valign="top">&bull;</td>
              <td width="226" align="left" valign="top"><strong><a href="http://mbu.iisc.ernet.in/~vishgp/" target="_blank">Prof. Sarawathi Vishveshwara</a></strong><br />
                Department of Molecular  Biophysics Unit<br />
                Professor<br />
                Indian Institute of Science <br />
                Bangalore - 560 012 </td>
              <td width="272" align="left" valign="top">Phone: 91-80 -2293 2611<br />
                E-mail: <a href="mailto:sv@mbu.iisc.ernet.in">sv@mbu.iisc.ernet.in</a> <br /></td>
              <td width="133" align="left" valign="top"><img src="images/faculty-saraswathi.jpg" alt="Sarawathi Vishveshwara" width="125" height="125" class="imglink" /></td>
              </tr>
          </table>-->
          <div class="faculty"><img src="images/spacer.gif" width="100" height="1" alt=" " /></div>
<br />
<br />
<div class="gotopcontainer"><br />
  <div class="gotop"><a href="#top">Go Top</a></div>
</div>
          <br />
          <br />
          <p>&nbsp;</p></div></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

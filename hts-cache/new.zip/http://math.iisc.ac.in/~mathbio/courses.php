﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="courses.php">
      <div class="leftmenucell">Courses</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Workshops.php">
      <div class="leftmenucell">Workshop and Conference</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Alumni.php">
      <div class="leftmenucell">IMI Alumni Students</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>COURSES</strong></h1>
          <ul>
            <li>  <a href="SureshCourse.php">“High-Performance Scientific Computing on the GPU with emphasis on CAD and FEA”</a> <br />

              (Prof. K. Suresh, University of Wisconsin, Madison, USA)
			   
			           
			  
            </li><br/><br/>
			
			<li>  <a href="Compact_Course_Arni.php">“Mathematical Ecology - I”</a> <br />

              (Prof. Arni S.R. Srinivasa Rao, ISI, Kolkata)
			   
			           
			  
            </li>
			
			<br />
          </ul>
<pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

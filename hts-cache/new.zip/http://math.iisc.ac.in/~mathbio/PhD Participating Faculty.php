﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <!--<td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>-->
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Convener.php">
      <div class="leftmenucell">Convener</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="PhD Participating Faculty.php">
      <div class="leftmenucell">Participating Faculty</div>
    </a></td>
    
 <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="Intvwprocess.php">
      <div class="leftmenucell">Interview Process</div>
    </a></td>
    
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Students.php">
      <div class="leftmenucell">Students under Interdisciplinary Mathematical Sciences Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><span style="font-weight: bold">Participating Faculty:</span></h1>
          <p>            Each selected students will be 
            assigned (based on their interest) to two of the 
            following faculty members from two different 
            Departments.</p>
          <ul>
            <li>Dr. Shivani Agarwal<br />
          Department of Computer Science & Automation
<br />
          E-mail : <a href="mailto:shivani@csa.iisc.ernet.in">shivani@csa.iisc.ernet.in</a><br />
          <br />
        <li>Prof. G. K. Ananthasuresh<br />
          Department of Mechanical Engineering<br />
          E-mail : <a href="mailto:suresh@mecheng.iisc.ernet.in">suresh@mecheng.iisc.ernet.in</a><br />
          <br />
        </li>
		<li>Prof. S. P. Arun<br />
          Center for Neuroscience<br />
          E-mail : <a href="mailto:sparun@cns.iisc.ernet.in
">sparun@cns.iisc.ernet.in
</a><br />
          <br />
        </li>
        <li> Prof. Shalabh Bhatnagar<br />
          Department of Computer Science &amp; Automation<br />
          E-mail : <a href="mailto:shalabh@csa.iisc.ernet.in">shalabh@csa.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Chiranjib Bhattacharyya<br />
          Department of Computer Science &amp; Automation<br />
          E-mail : <a href="mailto:chiru@csa.iisc.ernet.in">chiru@csa.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Nagasuma Chandra<br />
          Supercomputer Education and Research Centre<br />
          E-mail : <a href="mailto:nchandra@serc.iisc.ernet.in">nchandra@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Anindya Chatterjee<br />
          Department of Mechanical Engineering<br />
          E-mail : <a href="mailto:anindya@mecheng.iisc.ernet.in">anindya@mecheng.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Arnab Rai Choudhuri<br />
          Department of Physics <br />
          E-mail :<a href="mailto:arnab@physics.iisc.ernet.in">arnab@physics.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Basudeb Datta<br />
          Department of Mathematics <br />
          E-mail :<a href="mailto:dattab@math.iisc.ernet.in">dattab@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Narendra M. Dixit<br />
          Department of Chemical Engineering<br />
          E-mail: <a href="mailto:narendra@chemeng.iisc.ernet.in">narendra@chemeng.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Siddhartha Gadgil<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:gadgil@math.iisc.ernet.in">gadgil@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Debasish Ghose<br />
          Department of Aerospace Engineering<br />
          E-mail : <a href="mailto:dghose@aero.iisc.ernet.in">dghose@aero.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Debraj Ghosh<br />
          Department of Civil Engineering<br />
          E-mail : <a href="mailto:dghosh@civil.iisc.ernet.in">dghosh@civil.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Mrinal K. Ghosh<br />
          Department of Mathematics <br />
          E-mail : <a href="mailto:mkg@math.iisc.ernet.in">mkg@math.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Thirupathi Gudi<br />
          Department of Mathematics <br />
          E-mail : <a href="mailto:gudi@math.iisc.ernet.in">gudi@math.iisc.ernet.in</a><br />
          <br /></li>
		  <li>Prof. Vishwesha Guttal<br />
          Department of Center for Ecological Sciences <br />
          E-mail : <a href="mailto: guttal@ces.iisc.ernet.in">guttal@ces.iisc.ernet.in</a><br />
          <br />
                </li>
        <li> Prof. Srikanth K. Iyer<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:skiyer@math.iisc.ernet.in">skiyer@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. N. V. Joshi<br />
          Centre for Ecological Sciences<br />
          E-mail : <a href="mailto:nvjoshi@ces.iisc.ernet.in">nvjoshi@ces.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. P. Vijay Kumar<br />
          Department of Electrical and Communication Engineering<br />
          E-mail : <a href="mailto:vijay@ece.iisc.ernet.in">vijay@ece.iisc.ernet.in</a> <br />
          <br />
        </li>
        <li> Prof. C. E. Veni Madhavan<br />
          Department of Computer Science &amp; Automation<br />
          E-mail : <a href="mailto:cevm@csa.iisc.ernet.in">cevm@csa.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Prabal K. Maiti<br />
          Department of Physics<br />
          E-mail : <a href="mailto:maiti@physics.iisc.ernet.in">maiti@physics.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Rina Maiti<br />
          Centre for Product Design and Manufacturing<br />
          Email : <a href="mailto:rmaiti@cpdm.iisc.ernet.in">rmaiti@cpdm.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. C. Mukhopadhyay<br />
          Department of Management Studies <br />
          E-mail : <a href="mailto:cm@mgmt.iisc.ernet.in">cm@mgmt.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Dr. Aditya Murthy<br />
          Centre For Neuroscience<br />
          E-mail : <a href="mailto:aditya@cns.iisc.ernet.in
">aditya@cns.iisc.ernet.in
</a><br />
          <br />
        </li>
        <li> Prof. A. K. Nandakumaran<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:nands@math.iisc.ernet.in">nands@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Vidyanand Nanjundiah <br />
          Molecular Reproduction, Development &amp; Genetics<br />
          E-mail : <a href="mailto:vidya@ces.iisc.ernet.in">vidya@ces.iisc.ernet.in</a><br />
          <br />
        </li>
		 <li> Prof. Rishikesh Narayanan<br />
          Molecular Biophysics Unit
<br />
          E-mail : <a href="mailto:rishi@mbu.iisc.ernet.in">rishi@mbu.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Vijay Natarajan<br />
          Department of Computer Science and Automation<br />
          E-mail : <a href="mailto:vijayn@csa.iisc.ernet.in">vijayn@csa.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Radhakant Padhi<br />
          Department of Aerospace Engineering<br />
          E-mail : <a href="mailto:padhi@aero.iisc.ernet.in">padhi@aero.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Debnath Pal<br />
          Supercomputer and Education Research Centre<br />
          E-mail : <a href="mailto:dpal@serc.iisc.ernet.in">dpal@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Rahul Pandit <br />
          Department of Physics <br />
          E-mail : <a href="mailto:rahul@physics.iisc.ernet.in">rahul@physics.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Phoolan Prasad<br />
          Department of Mathematics <br />
          E-mail : <a href="mailto:prasad@math.iisc.ernet.in">prasad@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Dr. Soumyendu Raha<br />
          Supercomputer and Education Research Centre<br />
          E-mail : <a href="mailto:raha@serc.iisc.ernet.in">raha@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. B. Sundar Rajan<br />
          Department of Electrical &amp; Communication Engineering<br />
          E-mail : <a href="mailto:bsrajan@ece.iisc.ernet.in">bsrajan@ece.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Sriram Ramaswamy<br />
          Department of Physics<br />
          E-mail : <a href="mailto:sriram@physics.iisc.ernet.in">sriram@physics.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Dr. Annapoorni Rangarajan<br />
          Molecular Reproduction, Development & Genetics<br />
          E-mail : <a href="mailto:anu@mrdg.iisc.ernet.in">anu@mrdg.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Govindan Rangarajan<br />
          Department of Mathematics<br />
          E-mail : <a href="mailto:rangaraj@math.iisc.ernet.in">rangaraj@math.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. S. V. Raghurama Rao<br />
          Department of Aerospace Engineering<br />
          E-mail : <a href="mailto:raghu@aero.iisc.ernet.in">raghu@aero.iisc.ernet.in</a><br />
          <br />
        </li>
		 <li> Prof. Debasish Roy<br />
          Department of Civil Engineering<br />
          E-mail : <a href="mailto:royd@civil.iisc.ernet.in">royd@civil.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Diptiman Sen<br />
          Centre for High Energy Physics<br />
          E-mail : <a href="mailto:diptiman@cts.iisc.ernet.in">diptiman@cts.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Vinod Sharma<br />
          Department of Electrical Communication Engineering<br />
          E-mail : <a href="mailto:vinod@ece.iisc.ernet.in">vinod@ece.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. S. K. Sikdar<br />
          Molecular Biophysics Unit<br />
          E-mail : <a href="mailto:sks@mbu.iisc.ernet.in">sks@mbu.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. J. Srinivasan<br />
          Centre for Atmospheric and Oceanic Sciences<br />
          E-mail : <a href="mailto:chairman@cas.iisc.ernet.in">chairman@cas.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. N. Srinivasan<br />
          Molecular Biophysics Unit<br />
          E-mail : <a href="mailto:ns@mbu.iisc.ernet.in">ns@mbu.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. R. M. Vasu<br />
          Department of Instrumentation<br />
          E-mail : <a href="mailto:vasu@isu.iisc.ernet.in">vasu@isu.iisc.ernet.in</a><br />
          <br />
        </li>
		<li> Prof. Murugesan Venkatapathi <br />
         Supercomputer Education and Research Center<br />
          E-mail : <a href="mailto: murugesh@serc.iisc.ernet.in"> murugesh@serc.iisc.ernet.in</a><br />
          <br />
        </li>
        <li> Prof. Saraswathi Vishveshwara<br />
          Molecular Biophysics Unit<br />
          E-mail : <a href="mailto:sv@mbu.iisc.ernet.in">sv@mbu.iisc.ernet.in</a> <br />
        <br />
		</li>
		<li> Prof. Phaneendra K. Yalavarthy<br />
          Supercomputer Education and Research Centre<br />
          E-mail : <a href="mailto: phani@serc.iisc.ernet.in"> phani@serc.iisc.ernet.in</a><br />
          <br />
        </li>
          </ul>
          <div class="gotopcontainer"><br />
  <div class="gotop"><a href="#top">Go Top</a></div><br /><br /></div><br />
          <p align="justify">&nbsp;</p>
          <p>&nbsp;</p></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

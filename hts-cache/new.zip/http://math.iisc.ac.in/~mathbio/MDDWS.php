﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="MDDWSOrgCom.php">
      <div class="leftmenucell">Organizing Committee</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="MDDWSResourcePersons.php">
      <div class="leftmenucell">Resource Persons</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="MDDWSVenue.php">
      <div class="leftmenucell">Venue</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Workshops.php">
      <div class="leftmenucell">Workshop and Conference</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <td> <a href="http://math.iisc.ernet.in/%7Eimi/math-biorequestforparticipation.php">
      <div class="leftmenucell">
        Request for Participation

</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
    <tr>
    <td><a class="left" href="MDDWSdeadlines.php">
      <div class="leftmenucell">Deadline</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>Workshop - Symposium on 
Mathematics in Drug Discovery <br/><br />

September 25 - 29, 2010
 </strong></h1>
          <div align="justify">Mathematical and computational techniques are used extensively in drug discovery research. Most are hidden within software packages and the end-user is barely aware of them. This residential workshop and symposium in the DST-IISc Year of Mathematical Biology aims to educate participants about the fundamental mathematical principles and techniques used at various stages of the drug discovery process, and to give a glimpse of ongoing research activities in these areas.  It is targeted at final year Masters degree students, doctoral students, postdoctoral fellows, and young researchers from both physical and life sciences backgrounds who are interested in the field of drug discovery. This activity is jointly organized by the DST Centre for Mathematical Biology at IISC, the IISc Mathematics Initiative, Piramal Life Sciences Ltd and NCL-Pune.
            <br />
          </div>
          <h1>Topics for the workshop:</h1>
		  <ol>
			  <li>Mathematics in description/analysis of small organic molecules – energy functions, descriptors etc</li>
		      <li>Mathematics in developing models of 3D structures of proteins – from XRD data, NMR data and computational approaches </li>
		      <li>Mathematics in analysis of protein 3D structures – protein flexibility using molecular dynamics simulations, normal mode analysis, graph theory</li>
		      <li>		 Mathematics in matching 3D shapes and features of small molecule and protein binding pocket – docking</li>
		      <li>Mathematics in modeling pharmacokinetics/ pharmacodynamics</li>
			  		       <li> Mathematical modeling of structure – activity relationships – QSAR <br />
		        <br />
		        There will be a few symposium-style talks by researchers on original theoretical work done by them and case studies of applications covered in the Workshop. </li>
		      <!--<li> Signal transduction: mechanistic and data analysis models for target
		        identification. </li>
		      <li>      Single molecule chemistry for drug </li>
			  <li>      QSAR, pharmacophore modeling </li>
			  <li>      Design and analysis of Bioassays </li>
			  <li>      Pharmacokinetics/ dynamics </li>
			  <li>      Scaling issues: from animal models to clinical trials </li>
			  <li>      Protein structure:<br />
			    a.       3D models from XRD/NMR data<br />
		        b.      3D from sequence, other databases<br />
		        c.       MD simulations<br />
	          d.      Docking</li>
	          <li>      Clinical trial design and analysis </li>
			  <li>      Participant short presentation/discussion <br />
			    
			    -->
			    
			    <BR> 
			    <BR>
			    
			    </ul>
		      </li>
			</ol>
		  <pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

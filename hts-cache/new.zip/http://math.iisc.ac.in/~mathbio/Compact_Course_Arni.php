﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="courses.php">
      <div class="leftmenucell">Courses</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>COMPACT COURSE 2011 </strong></h1>
          <ul>
            <div align="center">
            <div align="center"><strong>“Mathematical Ecology - I”</strong><br />
                <br />
              by<br />
              <br />
              
              <strong>Prof. Arni S.R. Srinivasa Rao</strong><br /> 
            ISI, Kolkata<br />
            <br />
             
        from<br />
        <br />
        <strong>February 21 - 25, 2011</strong><br /><br/>
        <br />      
            </div>
			<div align="center"><strong>Venue: </strong>Centre for Ecological Sciences, IISc, Bangalore		    </div>
			<p align="center"><strong>Schedule is as follows:</strong><br />
	  Monday, 3 PM - 6 PM, CES Seminar Hall<br />
                     Tuesday, 10 AM - 1 PM, CES Seminar Hall<br />
                   Wednesday, 3 PM - 6 PM, CES Room 420 (Terrace)<br />
                      Thursday, 3 PM - 6 PM, CES Seminar Hall<br />
                       Friday,  3 PM - 6 PM, CES Seminar Hall<br />
        <br />
        <strong>Abstract<br/>
                                  **********</strong><br/>
                                  <br/></p>

            <div align="justify">Preliminaries: Introduction to the mathematical ecology, Mathematical
              tools (algebra and calculus) required for the course. Refreshing of
              Mathematical tools.<br/>
  <br/>
              
              Populations: Homogeneous population exponential, geometric growth and
              decay, Age-and stage-structured linear models : relaxing the assumption of
              population homogeneity, Nonlinear   models of signal population the
              continuous time logistic model.<br/>
  <br/>
              
              Dynamics: Discrete logistic growth, oscillations, and chaos, Harvesting
              and the logistic model,  Predators and their prey, Competition between two
              species, mutualism, and species invasions   Multispecies community and
              food web models.<br/>
  <br/>
              
              
              References:<br/>
  <br/>
              1. Differential Equations with Applications and Historical Notes by
G.F. Simmons (Tata McGraw Hill Edition, 2003)<br/>
              2. Mathematical Biology Volumes 1 and 2 by J.D. Murry (Springer, 3/e, 2002)<br/>
              3. Mathematical Ecology by John Pastor (Wiley-Blackwell, 2008)
              
              
              <br />
              <br />
              <br />
            
          <pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <!--<tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>-->
   <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Convener.php">
      <div class="leftmenucell">Convener</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="PhD Participating Faculty.php">
      <div class="leftmenucell">Participating Faculty</div>
    </a></td>
    
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="Intvwprocess.php">
      <div class="leftmenucell">Interview Process</div>
    </a></td>
    
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Students.php">
      <div class="leftmenucell">Students under Interdisciplinary Mathematical Sciences Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>Students:</strong></h1>
		  <ol>
        <strong>2006 Batch Students</strong><br /><br />
		<li>SASWATI DANA</li><br />
		<li>S. R. SUDARSHAN</li><br /></ol>
		
		<ol>
        <strong>2008 Batch Students</strong><br />
		
				</li><br /><li>SAPTAK BANERJEE </li><br />
				<li>SOMA GHOSH </li>
				<br />
        <li>RICHA MUDGAL</li><br />
        
        <li>	SRISHTI SHUKLA</li><br />
         <li>	SAMAR BAHADUR SINGH</li><br /></ol>
		 
		 <ol>
        <strong>2009 Batch Students</strong><br /><br />
		 
        <li>          NITIN SINGH</li><br /><li>          PRATITI BHADRA</li><br /><li>          SATADAL GHOSH</li><br />
        <li>          SUMANTA MUKHERJEE</li><br />
        <li>          RAVI PRASAD</li><br /></ol>
		
		 <ol>
        <strong>2010 Batch Students</strong><br /><br />
		
		      <li>GAYATRI RAMAKRISHNAN</li><br />
        <li>         SATYA PRAKASH RUNGTA</li><br />
        <li>          DIGHE ANASUYA VIKAS</li><br /><li>          NAVIN</li><br />
		 </ol>
		
		<ol>
        <strong>2011 Batch Students</strong><br /><br />
		
		<li>RAGHU BHAGAVAT B R </li><br />
		 <li>ABHINAV DUBEY </li><br />
		  <li>PRACHI MEHROTRA </li><br />
		   <li>ANKIT RUHI </li><br />
		    <li>SHIRHATTI VINAY DHRUVA </li><br /></ol>
			
			<ol>
        <strong>2012 Batch Students</strong><br /><br />
		
		<li>RAHUL METRI </li><br />
		 <li>BHARATH KUMAR ETHAMKULA </li><br />
		  <li>AKHILA M. V</li><br />
		   <li>VASUNDHARA. G </li><br />
		    <li>KAVITHA MADHU </li><br /><li>SHWETA SRIVASTAVA </li><br /></ol>
			
			<ol>
        <strong>2013 Batch Students</strong><br /><br />
		
		<li>DIBYAJYOTI MAITY </li><br />
		 <li>MD MASIUR RAHAMAN </li><br />
		  <li>SR. SATHYA BAARATHI</li><br />
		   <li>SALELKAR SIDDHESH PRAMOD</li><br />
		    <li>MANISH BHATT </li><br /></ol>
			
			<ol>
        <strong>2014 Batch Students</strong><br /><br />
		
		<li>SACHENDRA KUMAR</li><br />
		 <li>PAPRI MAJUMDER </li><br />
		  <li>NILADRI RANJAN DAS</li><br />
		   </ol>
          <br />
          <br />
          <br />
        </li>
  
  
  </li>
  
  
          <br />
          <p align="justify">&nbsp;</p>
          <p>&nbsp;</p></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="250" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="courses.php">
      <div class="leftmenucell">Courses</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Alumni.php">
      <div class="leftmenucell">IMI Alumni Students</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr><br /><br />
  <tr>
  <tr>
    <td><a class="left" href="Workshops.php">
      <div class="leftmenucell">Workshop and Conference</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
    <td> <a href="http://math.iisc.ernet.in/%7Eimi/math-biorequestforparticipation.php">
      <div class="leftmenucell">
        Request for Participation</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
</table></p></td>
        <td class="maintext" width="730" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>SPECIAL YEAR ON MATHEMATICAL BIOLOGY <br/><br/>
			 August 2010 - July 2011</strong></h1>
          <p align="justify"><br />
            There has been extensive research and development work in the last several decades in the broad area of mathematical biosciences. This has enriched both mathematics and biology. In India, however, there is a shortage of research personnel trained in mathematical biology. In order to alleviate this shortage and to provide a fillip to cutting-edge research in mathematical biology, it is proposed to organize a special year on mathematical biology from August 2010 to July 2011. A large number of workshops, symposia and conferences are planned. These are listed below. This special year is funded by the Department of Science and Technology. The activities are being jointly organized by the DST Centre for Mathematical Biology at IISc, IISc Mathematics Initiative (IMI) and several research/academic institutions including Andhra University, CCMB Hyderabad, IMSc Chennai, IISER Pune, IISER Kolkata, IIT Kanpur, NCL Pune, Piramal Life Sciences and Purdue University, USA. 
            
            
            
          
          <ul>
		  <li>  <a href="QGGAWS.php">One Day Workshop on Topics in Quantitative Genetics & Genome Analysis </a> <br />
              (August 28, 2010)</li><br /><br />
			  
            <li>  <a href="MIDWS.php">Workshop and Conference on Modeling Infectious Diseases</a> <br />

              (September 13 - 22, 2010) </li><br /><br />
			  
			  			   <li><a href="MDDWS.php">Workshop - Symposium on 
Mathematics in Drug Discovery </a><br />
(September 25 - 29, 2010)	</li><br /><br />
		       			   <li>  <a href="MEWS.php">Workshop and Symposium on Mathematical Ecology</a> <br />
		       (December 07 - 14, 2010) </li>
		       			   <br /><br />
			   <li> <a href="PSFFWS.php"> 
            Workshop on Proteins: Structure, Function and Folding</a><br />
		       (December 20 - 24, 2010) </li>
			   <br /><br />
		      <li> <a href="MTLSWS.php">Workshop on Introduction to Mathematical Techniques in Life Sciences </a> <br />
		       (January 04 - 12, 2011) </li>
		      <br /><br />
			   <li><a href="MPWS.php">Workshop and Symposium on Mathematical Physiology </a> <br />
		       (January 15 - 23, 2011) </li>
			   <br /><br />
			   <li><a href="SBMEEWS.php">Workshop on Stability & Bifurcation Analysis and Pattern Formation in Mathematical Ecology and Epidemiology</a> <br />
		       (February 25 - March 02, 2011) </li><br /><br />
			 <li><a href="MBConf.php">International Conference on Mathematical Biology </a> <br />
		      (July 04 - 07, 2011) </li><br/><br/>
			<li><a href="MiniSymp.php">Mini-Symposium on Analysis and simulation of biomolecular structures  </a> <br />
		      (July 08, 2011) </li>
			<p><br/>
			</p>
			<center><h3>Other Events</h3></center><br />
			<a href="TEI Aug.php"><strong>International meeting on “Theoretical and Experimental Immunology”</strong></a>


			
          </ul>
		  <pre>&nbsp;</pre></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>

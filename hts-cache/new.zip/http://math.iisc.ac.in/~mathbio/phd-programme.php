﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MathBio - DST Centre for Mathematical Biology</title>
<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head><body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" align="left" valign="middle"><a name="top" id="top"></a><img src="images/spacer.gif" width="100" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td width="250" height="100" align="center" valign="middle" bgcolor="#FFFFFF"><a href="index.php"><img src="images/logo.jpg" alt="MathBio" width="255" height="100" border="0" /></a></td>
    <td width="730" height="100" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/banner.jpg" width="725" height="100" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><img src="images/spacer.gif" width="100" height="5" alt=" " /></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="980" valign="top" bgcolor="#FFFFFF" ><table width="980" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="256" valign="top" bgcolor="#FFFFFF"><br />
          <p>
<table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a class="left" href="index.php">
      <div class="leftmenucell">Home</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <!--<tr>
    <td><a class="left" href="visitorsprogramme.php">
      <div class="leftmenucell">Visitors Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="listofassociatedfaculty.php">
      <div class="leftmenucell">List of Associated Faculty</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="seminars.php">
      <div class="leftmenucell">Seminars</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="book_list.php">
      <div class="leftmenucell">Library</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="computingfacility.php">
      <div class="leftmenucell">Computing Facility</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="fundingagency.php">
      <div class="leftmenucell">Funding Agency</div>
    </a></td>
  </tr>
  -->
  <tr>
    <td><a class="left" href="phd-programme.php">
      <div class="leftmenucell">Ph.D. Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Convener.php">
      <div class="leftmenucell">Convener</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="PhD Participating Faculty.php">
      <div class="leftmenucell">Participating Faculty</div>
    </a></td>
    
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
  <td><a class="left" href="Intvwprocess.php">
      <div class="leftmenucell">Interview Process</div>
    </a></td>
    
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="PhD Students.php">
      <div class="leftmenucell">Students under Interdisciplinary Mathematical Sciences Programme</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="Alumni.php">
      <div class="leftmenucell">IMI Alumni Students </div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
   <tr>
    <td><a class="left" href="propos.php">
      <div class="leftmenucell">Project Proposals</div>
    </a></td>
  </tr>
  <tr>
    <td><img src="images/spacer.gif" width="200" height="8" alt=" " /></td>
  </tr>
  <tr>
    <td><a class="left" href="contact.php">
      <div class="leftmenucell">Contact</div>
    </a></td>
  </tr>
</table></p></td>
        <td class="maintext" width="724" valign="top" bgcolor="#FFFFFF"><h1>&nbsp;</h1>
          <h1><strong>Ph.D. PROGRAMME</strong></h1>
          <p align="justify">The Ph.D. in Interdisciplinary Mathematical Sciences
            is administered by the IISc Mathematics Initiative (IMI). This programme provides an unique opportunity 
            for students to work in areas spanning mathematics, 
            biology, physics and engineering. Students can work in 
            any of the interdisciplinary research areas mentioned 
            below. Each selected student will work with two 
            research supervisors (from two different Departments). 
            For example, a student can have supervisors from 
            Mathematics and an Engineering Department or Biology 
            and an Engineering Department or Physics and 
            Mathematics Departments. </p>
			
			
          <p align="justify" style="font-weight: bold">Eligibility Criteria: </p>
          <ul>
            <li>M Sc or equivalent degree in Mathematics, Statistics, Physics, Chemistry, Biology <br />
              <br />
              or <br />
              <br />
            </li>
            <li> ME/M Tech or equivalent degree in Engineering 
              discipline <br />
              <br />
              or<br />
              <br />
            </li>
            <li> BE/B Tech or equivalent degree in Engineering
              discipline</li>
          </ul>
          <p align="justify"><span style="font-weight: bold">Research Areas:</span><br />
            System biology; computational 
            neuroscience; computational biophysics; computational 
            biology; evolutionary biology; theoretical biology; 
            viral dynamics; constrained biomolecular dynamics;
            mathematical immunology; numerical analysis, 
            computational fluid dynamics and scientific 
            computation; wireless communication and sensor 
            networks; stochastic optimal control; mathematical 
            finance; partial differential (algebraic) equations; 
            optimization; computational geometry and topology; 
            computational geometry and data visualization; inverse 
            boundary value problem in the context of imaging; 
            coding theory and techniques; game theory.<br/>
      </p>
          
          <div align="justify"><strong>Click here for: <a href = "http://admissions.iisc.ernet.in/web/ApplicationInstructions.aspx">Application Procedure </a></strong><br/>   <br/> 
        
        
        <strong>If you are intrested in this programme please select your preference department as Interdisciplinary Mathematical Sciences Programme in the online application form. </strong></div align></p>
          <br />
          <ul>
		  <br />MSc candidates should choose their branch/specialization as explained
below Branch/Specialization: If you have studied branch in:<br /><br />
        <li>Any of the biological science fields like biology, microbiology,
          zoology, genetics, biotechnology etc., you should select &ldquo;Biological
          Sciences&rdquo; as your branch.<br/>
          <br/>
        </li>
        <li>Any of the chemical science fields like organic chemistry, applied
          chemistry, inorganic chemistry, chemistry etc., you should select
          &ldquo;Chemical Sciences&rdquo; as your branch.<br/>
          <br/>
        </li>
        <li>Any of the physical science fields like applied physics, radio
          physics,geophysics, physics etc., you should select &ldquo;Physical
          Sciences&rdquo; as your branch.<br/>
          <br/>
        </li>
        <li>Any of the mathematical science fields like applied mathematics,
          statistics, mathematics etc., you should select &ldquo;Mathematical
          Sciences&rdquo; as your branch.</li>
      </ul>
		  </p>
          <p align="justify">&nbsp;</p>
          <p align="justify">&nbsp;</p>
          <br />
          <p><br />
            <br />
          </p>
          <br />
          <p align="justify">&nbsp;</p>
          <p>&nbsp;</p></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><hr /></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="5" alt=" " /></td>
  </tr>
  <tr>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
    <td width="480" align="left" valign="top" bgcolor="#FFFFFF"><span class="smalltext">&nbsp;Copyright: MathBio</span></td>
    <td width="480" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="10" align="left" valign="middle" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="10" height="20" alt=" " /></td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="middle" bgcolor="#990000"><img src="images/spacer.gif" width="100" height="10" alt=" " /></td>
  </tr>
  </table>
</body>
</html>
